## Rubric

| Description | 1 mark each | 
| --- | --- |
| The hailstone algorithm is implemented according to explanation in the video. | |
| The method uses recursion. | |
| The method `hailstoneSteps()` throws an `IntegerOverflowException` when integer overflow occurs. | |
| Variable names are meaningful and easy to understand. | |
| All nine tests pass. | /4|
| Java conventions are followed. | |
| Line comments are used effectively. | |

**Date and Time:**

**Overall Score:** 10/10
