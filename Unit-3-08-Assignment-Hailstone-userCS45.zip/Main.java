/**
 * @author userCS45
 */

public class Main {
  /**
   * Takes a positive integer and uses a recursive approach to 
   * calculate the number of steps it would takes this integer to 
   * reach 1 using the algorithm provided in the video below:
   * https://www.youtube.com/watch?v=5mFpVDpKX70
   *
   * If at any point there is integer overflow,
   * the method throws an IntegerOverflowException.
   * 
   * @throws IntegerOverflowException
   * @param n an integer
   * @return the number of steps to reach 1
   */
  public static int hailstoneSteps(int n) throws IntegerOverflowException {

    if(3*n-2 >= Integer.MAX_VALUE || n*2+1 >= Integer.MAX_VALUE){ //If overflow will be a problem later in the code
      throw new IntegerOverflowException(); //Throw overflow exception 
    }
    if(n == 1){ //if n is equivelent to 1 (base case)
      return 0; //return the value of 0
    }else if(n%2 == 0){ //If the number is even
      return hailstoneSteps(n/2) + 1; //Call the same funstion and return n divided by 2 plus one to count. 
    }else if (n%2 == 1){ //If the number is odd
      return hailstoneSteps(3*n + 1) + 1; //Call the same function and return n times 3 plus one. 
    } 
    return 0;
  }


  /**
   *
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    try { //Tests
      UnitTests.runTests();
    } catch (Exception e) {
      System.out.println(e);
    }
  }
}
