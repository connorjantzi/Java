
/**
 *
 * @author userCS45
 */

import java.util.Arrays;

public class Main {
  /**
   * Uses the Sandwich Sort algorithm to sort a list of integers in numerical
   * order from least to greatest.
   *
   * The Sandwhich Sort algorithm is demonstrated in the video below:
   * https://drive.google.com/file/d/1DkXcFB81hnptv6Dk_ie5L0Fmdn4WGmSe/view?usp=sharing
   * 
   * @param array the array of integers
   */
  public static void sandwichSort(int[] array) {

    if (array.length > 1) { //Make sure there is more than one element in the array
      //Set variable to the correct values
      int firstIndex = 0;
      int lastIndex = array.length - 1;
      int min = array[0];
      int max = array[array.length - 1];
      int maxIndex = array.length-1;
      int minIndex = 0;
      int temp = 0;
      
      while (lastIndex >= firstIndex) { //Loop until reach the middle
        for (int i = firstIndex; i <= lastIndex; i++) { //Loop though the array

          if (array[i] >= max) { //If new max value if found
            //Set variable accordingly.
            max = array[i];
            maxIndex = i;
          }
        }
        //Swap the two element so the larger one is at the end.
        temp = array[lastIndex];
        array[lastIndex] = array[maxIndex];
        array[maxIndex] = temp;

        //Loop for the min value
        for (int i = firstIndex; i <= lastIndex; i++) {
          if (array[i] <= min) { //If smallest value is found
            //Set variable accordingly
            min = array[i];
            minIndex = i;
          }
        }
        //Swap variable to the smallest number is at the beginning
        temp = array[firstIndex];
        array[firstIndex] = array[minIndex];
        array[minIndex] = temp;

        //Make the index small at both ends
        firstIndex++;
        lastIndex--;
        //Reset the min and max values
        min = array[firstIndex];
        max = array[lastIndex];
      }
    }
  }

  /**
   * 
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    UnitTests.runTests();
  }
}
