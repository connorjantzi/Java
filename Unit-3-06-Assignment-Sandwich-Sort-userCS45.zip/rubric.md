## Rubric

| Description | 1 mark each | 
| --- | --- |
| The method correctly sorts any array of integers. | |
| The sorting algorithm is implemented according to Sandwich Sort in the video. | |
| Variable names are meaningful and easy to understand. | |
| All ten tests pass. | /5|
| Java conventions are followed. | |
| Line comments are used effectively. | |

**Date and Time:**

**Overall Score:** 10/10
