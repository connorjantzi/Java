/**
 * @author userCS45
 */

public class Main {
  
  /**
   * Calculates the number of real roots in the quadratic relation ax^2 + bx + c.
   *
   * @param a
   * @param b
   * @param c
   * @return int
   */
  public static int numRoots(double a, double b, double c) {
    int realRoots; 
    int discriminant = (int) Math.floor((b*b)-(4*a*c)); //Finding the discriminant. 
    
    if (discriminant > 0){ //If the disciminant if great than zero there is 2 real roots. 
      realRoots = 2;  
    }
    else if (discriminant == 0){ // If the disciminant is zero there is 1 real roots. 
      realRoots = 1;
    }
    else { // If the disciminant is less than zero there is 0 real roots. 
      realRoots = 0; 
    }
    return realRoots;
  }

  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    //Tests:
    System.out.println("The quadratic relation y = 4x^2 - 10 has " + numRoots(4, 0, -10) + " real root(s).");
    System.out.println("The quadratic relation y = 2.5x^2 - x + 12.2 has " + numRoots(2.5, -1, 12.2) + " real root(s).");
    System.out.println("The quadratic relation y = x^2 + 6.4x + 10.24 has " + numRoots(1, 6.4, 10.24) + " real root(s).");
  }
}