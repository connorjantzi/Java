/**
 *
 * @author userCS45
 */

import java.util.Arrays;

public class Main {
    
  /**
   * Takes an array of doubles and returns the second lowest double.
   * 
   * If the array is empty or has only one item, it returns 0.0.
   * 
   * Does not sort the array as a part of its algorithm.
   *
   * @param array
   * @return double
   */
  public static double secondLowestNum(double[] array) {
    double lowestNum = array[0];
    double secondLowestNum = lowestNum;
    if(array.length < 2){ //If there is only one item in array
      return 0.0;
    } else if (array.length >= 2){ //if there is 2 or more items in array
      for(int i = 0; i<array.length; i++){ 
        if(array[i] < lowestNum){ //if it is the lowest number set lowest num to that number
          lowestNum = array[i];
        }
      }
      for(int i = 0; i<array.length; i++){ //Find second lowest NUmber
        if(array[i] < secondLowestNum && array[i] != lowestNum){
          secondLowestNum = array[i]; //Put that number in the second lowest number variabe 
        }
      }
    }
    return secondLowestNum;
  }
      
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    double [] arrayOne = new double[]{4.6, 7.0, 9.0, 1.9, 4.2, 19.3, 45.8, 7.0};
    double [] arrayTwo = new double[]{2.0, 6,6, 6.5, 0.5};
    double [] arrayThree = new double[]{3.0};
    double [] arrayFour = new double[]{106.9, 10.6};
    
    System.out.println("Second lowest number: " + secondLowestNum(arrayOne));
    System.out.println("Second Lowest Number: " + secondLowestNum(arrayTwo));
    System.out.println("Second Lowest Number: " + secondLowestNum(arrayThree));
    System.out.println("Second Lowest Number: " + secondLowestNum(arrayFour));
  } 
}
