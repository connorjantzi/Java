## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The method `secondLowestNum()` returns the second lowest number in `array`.
✓ If `array` has 0 or 1 items, the method returns `0.0`.
✓ The method does not sort `array` as a part of its algorithm.
✓ Test include a variety of cases such as base cases and edge cases (e.g. arrays with duplicate values).
✓ The program runs without any errors.
✓ The lines of code are indented correctly based on where they are placed.
✓ Line comments are effectively used.
✓ Java conventions are followed.