## Rubric

| Description | 1 mark each| 
| --- | --- |
| The algorithm for detecting "thou" mostly works. |1 |
| The algorithm for detecting "thou" works PERFECTLY |0.5 |
| The algorithm is easy to follow and uses string manipulation (no Arrays). |1 |
| Proper file I/O is used effectively |1 |
| Algorithm checks for more than just thou and Thou |1 |
| Algorithm is an effective way of solving this problem |1|
| Variable names are meaningful and easy to understand. |1 |
| Java conventions are followed. |1 |
| Line comments are present |1 |
| Line comments are used effectively. They describe program flow and are meaningful |1 |
| Proper spacing and structure |1 |

**Date and Time:** Oct 28 7pm

**Overall Score:** 10.5/11
