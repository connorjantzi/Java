/**
 * @author userCS45
 */
 
import java.io.*; 
import java.util.Scanner;

public class Main {

  /**
   * Takes a filename and returns the number of times the word "thou" appears in it.
   * 
   * @param filename
   * @return int
   * @throws java.io.IOException
   */
  public static int thouCount(String filename) throws IOException {  
    try {
      
      File file = new File(filename); //Create file object 
      
      Scanner scanner = new Scanner(file); //Create scanner

      int count = 0; //Varialbe to count number of thou's
            
      while (scanner.hasNext()) { //Loooping while there is a next word to input
         
        String token = scanner.next(); //Input the next word. 
        token.toLowerCase(); //Put all word to lowwer casse so case isn't a barrier. 
        if (token.contains("thou") || token.equalsIgnoreCase("thou")){ //Checking is it contains thou
          int letterCount = 0;
          letterCount = 0; //Reset letter counter each time
            
          for (int i = 0; i<token.length(); i++){ //Chekcing how many letters there is in the word. 

            if ((token.charAt(i) >= 65 && token.charAt(i) <= 90) || (token.charAt(i) >= 97 && token.charAt(i) <= 122)){//If the character nalized is a letter
              letterCount++; //Add to the letter count; 
              }
            }
          if (letterCount == 4){//Cheking if the letter count is four
            //Chekcing if the four letters are thou
            if (token.charAt(0) == 't' || token.charAt(0) == 'T'){ 
              if (token.charAt(1) == 'h' || token.charAt(1) == 'H'){
                if (token.charAt(2) == 'o' || token.charAt(2) == 'O'){
                  if (token.charAt(3) == 'u' || token.charAt(3) == 'U'){
                    count++; //If it is thou increase count 
                  } 
                }
              } 
            } 
          } 
          //Special cases
          if (token.contains("thou'") || token.contains("'thou")|| token.contains("-thou") || token.contains("thou-")){ //If thou is lead by ' or -. 
            count ++; //Increase the count. 
          }           
        }
      }
      scanner.close(); //Close scanner
      return count; //Reutnr count
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
      return 0;
    }
  }
    
  /**
   * 
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    try {
      //Tests
      thouCount("hamlet.txt");
      System.out.println("The number of times \"thou\" appears in Hamlet is: " 
                         + thouCount("hamlet.txt"));
      System.out.println("The number of times \"thou\" appears in Macbeth is: " 
                         + thouCount("macbeth.txt"));
      System.out.println("The number of times \"thou\" appears in Othello is: " 
                         + thouCount("othello.txt"));
      System.out.println("The number of times \"thou\" appears in Romeo and Juliet is: " 
                         + thouCount("romeoAndJuliet.txt"));
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
    }
  } 
}