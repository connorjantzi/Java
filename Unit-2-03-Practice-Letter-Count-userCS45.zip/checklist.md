## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The program runs without any errors.
✓ The output matchs the examples.
✓ String manipulation is used (no Arrays)
✓ Knowledge of ASCII is present
✓ The program is reasonably efficient (e.g. the file is read through only once within the method).
✓ The lines of code are indented correctly based on where they are placed.
✓ Line comments are effectively used.
✓ Java conventions are followed.