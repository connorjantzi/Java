/**
 * @author userCS45
 */
 
import java.io.*; //Import file class
import java.util.Scanner; //Import sccanner class

public class Main {

  /**
   * Takes a filename and returns the number of alphabet characters in it.
   * 
   * @param filename 
   * @return int
   * @throws java.io.IOException
   */  
  public static int letterCount(String filename) throws IOException { 
    int letterCount = 0; //Letter count variable
    try { // Exception handling
      File file = new File (filename); //Input file 
      Scanner scan = new Scanner (file); //Open scanner
      while (scan.hasNext()){ //Read the file until the end
        String fileInput; //Input one word at a time
        fileInput = scan.nextLine(); //Input from file 
        for(int i = 0; i < fileInput.length(); i++){ //Looping each character of the word 
          char letterHolder = fileInput.charAt(i); //Holding each character
          if ((letterHolder >= 65 && letterHolder <= 90) || (letterHolder >= 97 && letterHolder <= 122)){ //Cheching is it is a letter
            letterCount += 1; //Increasing the letter count by one
          }
        }
      }
       scan.close(); //Close scanner when done
      
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
      return 0;
    }
   
    return letterCount; //Return letter count
  }
    
  /**
   * 
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    try {
      System.out.println("The number of letters in Hamlet is: " 
                         + letterCount("hamlet.txt"));
      System.out.println("The number of letters in Macbeth is: " 
                         + letterCount("macbeth.txt"));
      System.out.println("The number of letters in Othello is: " 
                         + letterCount("othello.txt"));
      System.out.println("The number of letters in Romeo and Juliet is: " 
                         + letterCount("romeoAndJuliet.txt"));
    } catch (IOException exception) {
        System.out.println("Something is wrong with the file.");
    }
  }
}
