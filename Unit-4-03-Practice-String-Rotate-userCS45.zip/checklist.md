## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The algorithm works correctly
✓ A queue is used for the rotation
✓ 4 additional Tests included and have a variety of cases
✓ The program runs without any errors.
✓ The lines of code are indented correctly based on where they are placed.
✓ Line comments are effectively used.
✓ Java conventions are followed.