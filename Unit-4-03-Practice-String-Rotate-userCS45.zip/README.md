## Instructions

Complete the method stringRotate so that it uses a Queue to rotate the letters in a String by a specified amount. 

For example: 
If the original word is Telephone and you complete 4 rotations the rotated word should be phoneTele

One test case is provided for you, please include at least 4 more test cases in your submission that cover all of the necessary scenarios.

## Main.java

Here is the original code in main.java for reference

```java

/*
*@author name
*/

import java.util.*;

class Main {


  /*
  *A function that takes a string and the number of rotations and rotates letters around using a queue. 
  *If the original word is Telephone and you complete 4 rotations the rotated word should be phoneTele
  *
  *@Param String word
  *@Param int rotations
  *@Return String rotated word
  */
  public static String rotate(String word, int rotations){
    /*
    *What goes here?
    */

    return "";
  }

  /*
  *
  *@Param command line args
  */
  public static void main(String[] args) {

    // Here is one test case for you. Add 4 additional cases that cover a wide variety of scenarios

    String word = "Telephone";
    int rotations = 4;
    System.out.println("The original word is "+ word + " and with " + rotations + " rotations the rotated word is " + rotate(word, rotations));
  }
}
