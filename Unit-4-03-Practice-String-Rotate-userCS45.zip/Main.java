/*
*@author userCS45
*/

import java.util.*;

class Main {


  /*
  *A function that takes a string and the number of rotations and rotates letters around using a queue. 
  *If the original word is Telephone and you complete 4 rotations the rotated word should be phoneTele
  *
  *@Param String word
  *@Param int rotations
  *@Return String rotated word
  */
  public static String rotate(String word, int rotations){
   Queue<Character>wordToRotate = new LinkedList<Character>(); 
    for(int i = 0; i< word.length(); i++){ //Loop through word
      wordToRotate.add(word.charAt(i)); // Put into queue
    }
      for(int j = 0; j <rotations; j++){ //do for so many rotations
        char characterMoving = wordToRotate.peek(); // put character itno variable
        wordToRotate.remove(); //Remove first character
        wordToRotate.add(characterMoving); //add the character to the end 
      }
    
    return wordToRotate.toString();
  }

  /*
  *
  *@Param command line args
  */
  public static void main(String[] args) {

    // Tests

    String word = "Telephone";
    int rotations = 4;
    String wordOne = "Connor";
    int rotationsOne = 6;
    String wordTwo = "Test";
    int rotationsTwo = 6;
    String wordThree = " ";
    int rotationsThree = 2;
    String wordFour = "Cantalopes";
    int rotationsFour = 8;
    System.out.println("The original word is "+ word + " and with " + rotations + " rotations the rotated word is " + rotate(word, rotations));
    System.out.println("The original word is "+ wordOne + " and with " + rotationsOne + " rotations the rotated word is " + rotate(wordOne, rotationsOne));
    System.out.println("The original word is "+ wordTwo + " and with " + rotationsTwo + " rotations the rotated word is " + rotate(wordTwo, rotationsTwo));
    System.out.println("The original word is "+ wordThree + " and with " + rotationsThree + " rotations the rotated word is " + rotate(wordThree, rotationsThree));
    System.out.println("The original word is "+ wordFour + " and with " + rotationsFour + " rotations the rotated word is " + rotate(wordFour, rotationsFour));
  }
}