/**
 * @author userCS45
 */

public class Main {
  
  /**
   * Takes two integers, n and m, and prints all the powers of three inclusively between n and m.
   * 
   * @param n any positive integer
   * @param m any integer greater than or equal to n
   */
  public static void powersOfThree(int n, int m) {
    if (m>=n){//If the first number if greater than the second one. 
      for(int i = 0; i<=m; i++){ //looping to check for powers of three.  
        double powerOfThree = (Math.pow(3,i)); //Finding power of three
        if(powerOfThree>= n && powerOfThree <= m){ //if the powers of three are in between the declared variables. 
          System.out.println(String.format("%.0f", powerOfThree));//printing the number with out and decimal places. 
        }
      }
    }else{
    System.out.println("1st number is greater than the 2nd one."); //If the first number if greater than the second one. 
    }
  }

  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    /*
    *Tests
    */
    System.out.println("Powers of three:");
    powersOfThree(-1, 300);
    System.out.println("Powers of three:");
    powersOfThree(25, 800);
    System.out.println("Powers of three:");
    powersOfThree(-100, 3);
  }
}

