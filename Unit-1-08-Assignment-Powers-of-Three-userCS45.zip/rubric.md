## Rubric

| Description | 1 mark each | 
| --- | --- |
| The algorithm for calculating the powers of three works. | |
| The algorithm is easy to follow. | |
| Variable names are meaningful and easy to understand. | |
| The formatting matches the examples exactly. | |
| A wide variety of test cases are included. | |
| Java conventions are followed. | |
| Line comments are present | |
| Line comments are used effectively. They describe program flow and are meaningful | |
| Proper spacing and structure | |

**Date and Time:**

**Overall Score:**  9/9
