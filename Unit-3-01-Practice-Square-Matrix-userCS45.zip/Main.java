/**
 *
 * @author userCS45
 */

import java.util.Arrays;

public class Main {
    
  /**
   * Takes a 2-dimensional array of integers and determines whether it is a square matrix (i.e. the number of rows is the same as the number of columns).
   *
   * @param matrix
   * @return boolean
   */
  public static boolean isSquareMatrix(int[][] matrix) {
    boolean squareMatrix = false; 
    for(int i = 0; i < matrix.length; i++){
      if(matrix.length == matrix[i].length){
        squareMatrix = true; 
      }
      else{
        squareMatrix = false; 
        break;
      }
    }
    return squareMatrix; 
  }
      
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    int[] rowZero = new int[] {4,9,11,22};
    int[] rowOne = new int[] {8,3,45,32};
    int[] rowTwo = new int[] {43,82,91,0};
    int[] rowThree = new int[] {6,1,0,1};

    int[][] grid = {rowZero, rowOne, rowTwo, rowThree};
    System.out.println("Square matrix: " + isSquareMatrix(grid)); 
    
    int[] rowZero1 = new int[] {4,9,11,22};
    int[] rowOne1 = new int[] {8,3,32};
    int[] rowTwo1 = new int[] {43,82,91,};

    int[][] grid1 = {rowZero1, rowOne1, rowTwo1};
    System.out.println("Square matrix: " + isSquareMatrix(grid1));

    int[] rowZero2 = new int[] {4,9,11,22};
    int[] rowOne2 = new int[] {8,3,32};
    int[] rowTwo2 = new int[] {43,82,91,};
    int[] rowThree2 = new int[] {43,82,91,21};

    int[][] grid2 = {rowZero2, rowOne2, rowTwo2};
    System.out.println("Square matrix: " + isSquareMatrix(grid2));
  }
}
