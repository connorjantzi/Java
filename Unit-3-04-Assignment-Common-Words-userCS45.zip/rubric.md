## Rubric

| Description | 1 mark each | 
| --- | --- |
| The binary search algorithm works when the input is any word in the list. | |
| The binary search algorithm works when the input is a word that is not in the list. | |
| Variable names are meaningful and easy to understand. | |
| A wide variety of test cases are included. | |
| Java conventions are followed. | |
| Line comments are used effectively. | |

**Date and Time:**

**Overall Level:**  6/6
