/**
 * @author userCS45
 */
 
import java.io.*; 
import java.util.Scanner;
import java.util.Arrays; 

public class Main {
  // *commonWordsArray* will store the 5000 words in alphabetical order
  public static String[] commonWordsArray = new String[5000];

  /**
   * Puts each token from the file into commonWordsArray.
   * 
   * @throws java.io.IOException
   */
  public static void generateCommonWordsArray() throws IOException {
    try {
      File file = new File("words.txt");
      Scanner scanner = new Scanner(file);
      // Keeps track of the indices from 0 to 4999
      int index = 0;

      while (scanner.hasNext()) {
        // Adds each word to *commonWordsArray*
        commonWordsArray[index] = scanner.next();
        index++;
      }
      
      // Closes the scanner for good housekeeping
      scanner.close();
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
    }
  }

  /**
   * Takes a string and indicates whether it is in the
   * array commonWordsArray. 
   * 
   * Words are not case-sensitive (i.e. capitalization doesn't matter).
   * 
   * Uses a binary search algorithm for efficiency.
   * 
   * @param word 
   * @return boolean
  */
  public static boolean isCommonWord(String word) {
    //Put lower case
    word = word.toLowerCase();
    int middle = commonWordsArray.length/2; //find middle of array
    int low = 0; //varible for low value
    int high = commonWordsArray.length; //variable for high value
    //Finding that work in common word
    while(low <= high){ //Looping while high is greater than the low value
      middle = (low + high)/2; //Finding the middle by adding the high and low value and dividing by 2
      if(word.equals(commonWordsArray[middle])){ //Check if the word is in the middle
        return true; //When the word if found
      } else if (word.compareTo(commonWordsArray[middle]) > 0) { //check if the first word is before the second one
        low = middle + 1; //reseting the low vlaue accordinly
      }else{ //Other wise the second word is before the first
        high = middle - 1; //reseting the high variable accordingly
      }  
    }
    return false; //return false if word isn't found. 
  }
    
  /**
   * 
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    try {
      //tests
      generateCommonWordsArray();
      System.out.println("Word: come = "+ isCommonWord("come")); 
      System.out.println("Word: zum = "+ isCommonWord("zum"));
       System.out.println("Word: Able = "+ isCommonWord("Able"));
      System.out.println("Word: Sad = "+ isCommonWord("sad")); 
      System.out.println("Word GOAT = "+ isCommonWord("GOAT")); 
      System.out.println("Word aa = "+ isCommonWord("aa")); 
      
          
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
    }
  }
}
