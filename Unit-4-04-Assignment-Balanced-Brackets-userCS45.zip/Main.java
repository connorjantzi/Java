
/**
 *
 * @author userCS45
 */

import java.util.Stack;

public class Main {
  /**
   * Takes an string representing a piece of code and determines
   * whether all its brackets are balanced. All non-bracket
   * characters are ignored.
   * 
   * Brackets include parentheses "()", square brackets "[]", 
   * triangular brackets "<>", and curly braces "{}". 
   *
   * @param code a piece of code as a string
   * @return true if all the brackets are balanced; false otherwise
   */
  public static boolean hasBalancedBrackets(String code) {
    Stack<Character>openBrackets = new Stack(); //Stack to store opening brackets
    for(int i = 0; i< code.length(); i++){ //Loop through string
      if(code.charAt(i) == '{' ||  code.charAt(i) == '(' || code.charAt(i) == '[' || code.charAt(i) == '<'){ //If it is an opening bracket
        openBrackets.push(code.charAt(i)); //Put value into stack
        
      }else if (code.charAt(i) == '}' ||code.charAt(i) == ')' ||code.charAt(i) == ']' || code.charAt(i) == '>'){ //If closing bracket
        char closingBracket = getOpeningBracket(code.charAt(i)); //Find the corresponding opening bracket
        if(openBrackets.isEmpty() == true){ //If it is empty
          return false; 
        }if(openBrackets.pop() != closingBracket) { //Check if the opening bracket in the stack is the right bracket 
          return false; 
        }
      }
    }
    if(openBrackets.isEmpty() == false){ //If the stack still contains brackets 
      return false;
    } else{ //Otherwise return true
    return true;
    }
  }

  /**
   * Takes a closing bracket and returns its correponding opening bracket.
   *
   * If the input is not a closing bracket, it returns the null character.
   *
   * @param closingBracket a closing bracket character
   * @return the corresponding opening bracket (or the null character if N/A)
   */
  public static char getOpeningBracket(char closingBracket) {
    switch (closingBracket) {
      case ')':
        return '(';
      case ']':
        return '[';
      case '>':
        return '<';
      case '}':
        return '{';
    }
    return (char) 0;
  }

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    UnitTests.runTests();
  }
}
