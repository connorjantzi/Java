## Rubric

| Description | 1 mark each | 
| --- | --- |
| The algorithm for determining whether all brackets are balanced works. | |
| The algorithm ignores all non-bracket characters. | |
| Variable names are meaningful and easy to understand. | |
| All twelve tests pass. | /6|
| Java conventions are followed. | |
| Line comments are used effectively. | |

**Date and Time:**

**Overall Score:** 11/11
