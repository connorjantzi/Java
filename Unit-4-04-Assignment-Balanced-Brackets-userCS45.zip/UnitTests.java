/**
 *
 * @author MissStrong
 */

import java.util.Arrays;

public class UnitTests {
  /**
   * This method runs the twelve tests. 
   *
   * When a test passes, it prints a statement 
   * indicating it passed.
   *
   * When a test does not pass, it prints a statement 
   * indicating that it did not pass.
   */
  public static void runTests() {

    String[] balancedTests = {"", "a", "{}()[]<>", "{(<>)}[<>{}]", "(()((()())))", "((x+y)*3((1+7)-x))"};
    
    String[] nonBalancedTests = {"(", "><", "{}}", "[[]", "[)", "([)]"};

    for (int i = 0; i < 6; i++) {
      try {
        if (Main.hasBalancedBrackets(balancedTests[i])) {
          System.out.println(String.format("Test %d passed!", i + 1));
        } else {
          System.out.println(String.format("Test %d did NOT pass. ", i + 1));
        }
      } catch (Exception e) {
        System.out.println("Test %d did NOT pass");
      }
    }

    for (int i = 0; i < 6; i++) {
      try {
        if (!Main.hasBalancedBrackets(nonBalancedTests[i])) {
          System.out.println(String.format("Test %d passed!", i + 7));
        } else {
          System.out.println(String.format("Test %d did NOT pass. ", i + 7));
        }
      } catch (Exception e) {
        System.out.println(String.format("Test %d did NOT pass. ", i + 7));
      }
    }
  }
}
