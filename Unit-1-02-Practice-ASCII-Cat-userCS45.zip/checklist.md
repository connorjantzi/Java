## Checklist 

Check to make sure all instructions were followed before submitting this assignment.

✓ I replaced `name` next to the `@author` tag with my own repl.it username.
✓ No error messages are showing up.
✓ All characters in the cat are showing up, including `\` and `"`.
✓ All lines of the cat are identical to the example.