/**
 * @UserCS45
 */

public class Main {


  /**
   * Prints a cat.
   *
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    System.out.println(".         .");
    System.out.println(" \\'-\"'\"-\'/");
    System.out.println("  } 6 6 {");
    System.out.println("  =. Y .=");
    System.out.println("   /^^^\\ .");
    System.out.println("  /     \\ )");
    System.out.println("  ( )-( )/");
    System.out.println("   \"\" \"\"");
  }
}