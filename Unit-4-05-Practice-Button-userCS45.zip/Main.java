/**
 * @author userCS45
 */

import javax.swing.*; 
import java.awt.event.*;
import java.awt.*; 

public class Main {

  /**
   * Creates the GUI.
   *
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    JFrame frame = new JFrame();    
    ImageIcon cat = new ImageIcon("cat.jpg");
    ImageIcon dog = new ImageIcon("dog.jpg");
    frame.setSize(800, 600);
    frame.setLayout(null);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    JButton button = new JButton("Click");
    button.setBounds(200, 300, 800, 600);
    frame.add(button);

    button.setEnabled(true);
    button.setIcon(dog);

    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        if(button.getIcon() == dog){
          button.setIcon(cat);
        }else{
          button.setIcon(dog);
        }
        //System.out.println("test");
      }
    });
    
      
    
   
      
  
      

    
  }
}
