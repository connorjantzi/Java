## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The button initially displays `dog.jpg`.
✓ When the button displays `dog.jpg`, clicking it turns changes it to display `cat.jpg`.
✓ When the button displays `cat.jpg`, clicking it turns changes it to display `dog.jpg`.