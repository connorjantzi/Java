## Checklist

Check to make sure all instructions were followed before submitting this assignment.


✓ I replaced `name` next to the `@author` tag with my own repl.it username.
✓ I modified the strings below to with my own information and put these lines somewhere in `Main.java`.
```java
public static String name = "<Insert Your Name>";
public static String animal = "<Insert Your Favourite Animal>";
public static String tvShow = "<Insert Your Favourite TV Show>";
public static String musician = "<Insert Your Favourite Musician>";
```
✓ I put the following lines somewhere in `Main.java`.
```java
System.out.println("My name is _.".replace("_", name));
System.out.println("My favourite animal is _.".replace("_", animal));
System.out.println("My favourite TV show is _.".replace("_", tvShow));
System.out.println("My favourite musician is _.".replace("_", musician));
```
✓ The program runs without any errors and it prints out the information.
✓ The lines of code are indented correctly based on where they are placed.