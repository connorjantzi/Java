/**
 * @userCS45
 */

public class Main {
  /**
   * Prints some information about the user.
   *
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    String name = "Connor";
    String animal = "Tiger";
    String tvShow = "Brooklyn 99";
    String musician = "Taylor Swift";

    System.out.println("My name is _.".replace("_", name));
    System.out.println("My favourite animal is _.".replace("_", animal));
    System.out.println("My favourite TV show is _.".replace("_", tvShow));
    System.out.println("My favourite musician is _.".replace("_", musician));
  }
}
