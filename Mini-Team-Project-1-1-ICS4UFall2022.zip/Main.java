/* 
* @author cc9520
* @author heiml6305
* @author userCS45
*/

import java.util.Scanner;

class Main {

  public static void correctAnswer(int count) {
    System.out.println("That is the correct answer. Your total score is now " + count);
    return;
  }
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int totalScore = 0;
    System.out.print("Do you want to play a space themed quiz? Enter yes to continue: ");
    //first section is going to be true or false questions
    if(scanner.next().equalsIgnoreCase("yes")){
      System.out.println("1. Pluto is a planet. true or false: ");
      if(scanner.next().equalsIgnoreCase("false")){
        totalScore++; //adds one to total score
        correctAnswer(totalScore); //uses total score to print out using the method correctAnswer
      }
      else{
        System.out.println("That is the wrong answer. The correct answer is false"); //if the answer is not "false", prints this out
      }
      
      System.out.println("2. The universe is 13.7 billion years old. true or false: ");
      if(scanner.next().equalsIgnoreCase("true")){
        totalScore++; //same as q. 1
        correctAnswer(totalScore);
      }
      else{
        System.out.println("That is the wrong answer. The correct answer is true");
      }

        System.out.println("3. Our galaxy will collide with the Andromeda galaxy in 10 billion years. True or false: ");
      if(scanner.next().equalsIgnoreCase("false")){
        totalScore++; //same as q. 1
        correctAnswer(totalScore);
      }
      else{
        System.out.println("That is the wrong answer. The correct answer is false. Our galaxy will collide with the Andromeda galaxy in approximately 5 billion years.");
      }
    //multiple choice questions
      System.out.println("__________________");
      System.out.println("4. The seventh planet from the sun is:\n(a) Mercury\n(b) Earth\n(c) Saturn\n(d) Uranus");
      String answer = scanner.next();
      answer = answer.toLowerCase();
      if(answer.equals("d")){
        totalScore++;
        correctAnswer(totalScore);
      }
      else{
        System.out.println("That answer is incorrect. The correct answer is d"); 
      }

       System.out.println("5. What type of star is the sun? \n(a) Red giant\n(b) Main sequence\n(c) Red dwarf\n(d) None of the above");
      answer = scanner.next();
      answer = answer.toLowerCase();
      if(answer.equals("b")){
        totalScore++;
        correctAnswer(totalScore);
      }
      else{
        System.out.println("That answer is incorrect. the correct answer is b"); 
      }
      System.out.println("Your score is: " + totalScore);
    }
    else{
      System.out.println("I guess not :/");
    }
    
    scanner.close();
  }
}