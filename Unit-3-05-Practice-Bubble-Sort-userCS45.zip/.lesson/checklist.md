## Checklist

Check to make sure all aspects are complete befroe submitting this assignment

✓ all 5 arrays come back properly sorted
✓ bubble sort algorithm is implemented correctly according to it's definition
✓ The program runs without any errors.
✓ The lines of code are indented correctly based on where they are placed.
✓ Line comments are effectively used.
✓ Java conventions are followed.