/*
*@author userCS45
*/

import java.util.Arrays;

class Main {


  public static int[] bubbleSort(int[] array){
    int index = 0;
    int temp;
    int loopCounter = 1; 
    if(array.length > 1){ //if the array has more than one element 
      while(loopCounter != array.length){
        index = 0;
        while(index < (array.length-1)){
          if(array[index] > array[index+1]){
            temp = array[index];
            array[index] = array[index+1];  
            array[index+1] = temp; 
          }
          index++;
        }
            loopCounter++; 
          }
      }
      
    return array;
  }

  /**
  *param command line args
  */
  public static void main(String[] args) {
    // Test cases
    int[] array1 = {0};
    int[] array2 = {};
    int[] array3 = {4,4,4,1};
    int[] array4 = {8,7,6,5,4,3,2,1};
    int[] array5 = {6,3,8,1,3,9,0};

    System.out.println("Array 1 unsorted");
    System.out.println(Arrays.toString(array1));
    System.out.println("Array 1 sorted"); 
    System.out.println(Arrays.toString(bubbleSort(array1)));
    
    System.out.println("Array 2 unsorted");
    System.out.println(Arrays.toString(array2));
    System.out.println("Array 2 sorted"); 
    System.out.println(Arrays.toString(bubbleSort(array2)));    

    System.out.println("Array 3 unsorted");
    System.out.println(Arrays.toString(array3));
    System.out.println("Array 3 sorted"); 
    System.out.println(Arrays.toString(bubbleSort(array3)));

    System.out.println("Array 4 unsorted");
    System.out.println(Arrays.toString(array4));
    System.out.println("Array 4 sorted"); 
    System.out.println(Arrays.toString(bubbleSort(array4)));

    System.out.println("Array 5 unsorted");
    System.out.println(Arrays.toString(array5));
    System.out.println("Array 5 sorted"); 
    System.out.println(Arrays.toString(bubbleSort(array5)));
  }
}