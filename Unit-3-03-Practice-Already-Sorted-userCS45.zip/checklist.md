## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The method `isSorted()` correctly identifies lists sorted in ascending order.
✓ The method `isSorted()` correctly identifies lists sorted in descending order.
✓ The method `isSorted()` does not sort the array as a part of its algorithm.
✓ Test include arrays of floats in various sequences.
✓ The program runs without any errors.
✓ The lines of code are indented correctly based on where they are placed.
✓ Line comments are effectively used.
✓ Java conventions are followed.