
/**
 *
 * @author userCS45
 */

import java.util.Arrays;

public class Main {

  /**
   * Takes a one-dimensional array of doubles and returns true if the array is
   * already sorted in either ascending order or descending order and false
   * otherwise.
   *
   * This method does not sort the array as a part of its algorithm for
   * efficiency.
   *
   * @param array
   * @return boolean
   */
  public static boolean isSorted(int[] array) {
      int i = 0; 
      //For asending order
      if (array[i] < array[i + 1]) {
      for (int j = 0; j < array.length-1; j++) {
        if(array[j] > array[j+1]){
          return false;
        }
      }
    }
    if (array[i] > array[i + 1]) {
      for (int j = 0; j < array.length-1; j++) {
        if(array[j] < array[j+1]){
          return false;
        }
      }
    }
    return true;
  }

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    int[] arrayOne = new int[] { 2, 3, 4, 5, 6 };
    int[] arrayTwo = new int[] { 8, 7, 6, 5, 4, 3, 2, 1 };
    int[] arrayThree = new int[] { 5, 8, 2, 1, 5 };
    int[] arrayFour = new int[] { 8, 10, 12, 14 };

    System.out.println(isSorted(arrayOne));
    System.out.println(isSorted(arrayTwo));
    System.out.println(isSorted(arrayThree));
    System.out.println(isSorted(arrayFour));

  }
}