
## Rubric

| Description | 1 mark each | 
| --- | --- |
| The computer chooses a random word from *jottoWords.txt* at the beginning of every game. | | 
| If you guess a word that is not in  *jottoWords.txt* , it tells you that it is not a valid word. | |
| If you guess the same word more than once, it tells you that you have already guessed that word. | |
| When you guess a (new) word, the guess counter gets updated | |
| The text area gets updated with the words that have been guessed alongside the number of letters in common with the secret word. | |
| If you guess the word correctly, it tells you that you won and the number of guesses you took. | | 
| If you guess the word correctly, it prevents you from guessing any more words until you click *Play Again*. | |
| At any point, you can click *Give Up* to reveal the secret word. | |
| When you click *Give Up*, it prevents you from guessing more any words until you click *Play Again*. | |
| When you click *Play Again*, the computer choses a random word again from *jottoWords.txt*. | |
| When you click *Play Again*, the guess count and previous guesses are reset. | |
| Proper java conventions used | |
| Line comments are used effectively | |

___

### Additional Challenges

| Description | 1 mark each | 
| --- | --- |
| The cursor gets placed in the text field at the beginning of each game. | |
| The ENTER key is a keyboard shortcut for *Guess Word* during gameplay. | | 
| The ENTER key is a keyboard shortcut for *Play Again* when the game ends. | | 

__

**Date and Time:**

**Overall Grade:** 16/16