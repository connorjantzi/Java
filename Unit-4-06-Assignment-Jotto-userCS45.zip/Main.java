
/**
 * @author userCS45
 */

import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Robot.*;
import java.awt.event.*;
import static java.awt.event.KeyEvent.*;
import static java.awt.event.KeyAdapter.*;

public class Main extends JFrame {
  //Initialize variables
  boolean containsGuess = false;
  int numberOfCorrectLetters;
  int guessesSoFar = 0;
  
  boolean exceptions = false;
  JFrame frame = new JFrame("Jotto!");
  JLabel wordsGuessedLabel = new JLabel("Words Guessed:");
  JLabel nextGuessLabel = new JLabel("Next Guess:");
  JLabel validWordLabel = new JLabel();
  JTextArea wordsGuessedArea = new JTextArea();
  JLabel guessesSoFarLabel = new JLabel("Guesses so far: 0");
  JTextField nextGuessField = new JTextField();
  
  JButton guessWordButton = new JButton("Guess Word");
  JButton giveUpButton = new JButton("Give Up");
  JButton playAgainButton = new JButton("Play Again");
  JScrollPane wordsGuessedScroller = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

  // Additional variables initialized
  ArrayList<String> wordsGuessedList = new ArrayList();
  ArrayList<String> jottoWordsList = new ArrayList();
  String mysteryWord;
  ArrayList<Character> lettersAccountedFor = new ArrayList();

  public Main() { 
    
    // Pick a word from jottoWords.txt by creating an array with all the words from
    // jottoWords.txt and selecting a random index
    try {
      // Set up for file input
      File jottoTextFile = new File("jottoWords.txt");
      Scanner scanner = new Scanner(jottoTextFile);

      // fill arrayList with words from file
      while (scanner.hasNextLine()) {
        jottoWordsList.add(scanner.nextLine());
      }

      scanner.close();

    } catch (IOException exception) {
      System.out.println("An error occured.");
      System.out.println(exception);
      System.exit(0);
    }

    //Get the mystery word

    // Select a random word from the list
    int randomIndex = (int) (Math.random() * 100000 % 12470);
    mysteryWord = jottoWordsList.get(randomIndex);
    System.out.println(mysteryWord);
    

    frame.setSize(600, 600);
    frame.setLayout(null);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    

    // The "Words Guessed" label
    wordsGuessedLabel.setBounds(50, 0, 200, 50);
    wordsGuessedLabel.setFont(new Font("Dialog", Font.PLAIN, 20));
    frame.add(wordsGuessedLabel);

    // The "Next Guess" label
    nextGuessLabel.setBounds(400, 0, 200, 50);
    nextGuessLabel.setFont(new Font("Dialog", Font.PLAIN, 20));
    frame.add(nextGuessLabel);
    

    // The label that displays:
    // * "__ is not a valid word."
    // * "You've already guessed __".
    validWordLabel.setBounds(400, 175, 200, 100);
    validWordLabel.setFont(new Font("Dialog", Font.PLAIN, 20));
    frame.add(validWordLabel);

    // The label that displays:
    // * the number of guesses
    // * the secret word when you give Up
    // * "Jotto! You won in _ guesses."
    guessesSoFarLabel.setBounds(400, 250, 200, 100);
    guessesSoFarLabel.setFont(new Font("Dialog", Font.PLAIN, 20));
    frame.add(guessesSoFarLabel);

    // The text area below "Words Guessed" that
    // displays the words guessed and how many
    // letters match the secret word
    wordsGuessedArea.setBounds(50, 50, 300, 450);
    wordsGuessedArea.setFont(new Font("Dialog", Font.PLAIN, 20));
    wordsGuessedArea.setEditable(false);
    wordsGuessedScroller.setBounds(50, 50, 300, 450);
    wordsGuessedScroller.setViewportView(wordsGuessedArea);
    frame.add(wordsGuessedScroller);

    // The text field below "Next Guess" that
    // allows the user to guess words
    nextGuessField.setBounds(400, 50, 150, 50);
    nextGuessField.setFont(new Font("Dialog", Font.PLAIN, 20));
    frame.add(nextGuessField);
    //Setting the cursor in the next guess text field 
    nextGuessField.requestFocus();
    //Move cursor to that field and click so that the cursor is blinking
    try {
      Robot cursor = new Robot();
      cursor.mouseMove(430,92);
      Point clickCoords = new Point(430,95);
      cursor.mouseMove(clickCoords.x, clickCoords.y);
      //Press the mouse in the text box to make it blink
      cursor.mousePress(InputEvent.BUTTON1_DOWN_MASK);
      cursor.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
    } catch (AWTException e) {
      System.out.println("error");
    }
  
    // The "Guess Word" button when press enter
    nextGuessField.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent evt) {
        // VK_Enter is the key code for the ENTER key
        if (evt.getKeyCode() == VK_ENTER) {
     
          guessWordButton.doClick();
        }
      }
    });
    guessWordButton.setBackground(new Color(0, 122, 225));
    guessWordButton.setForeground(Color.WHITE);
    guessWordButton.setBounds(400, 125, 150, 50);
    guessWordButton.setFont(new Font("Dialog", Font.PLAIN, 18));
    guessWordButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        //Reseting the variable everytime
        exceptions = false;
        containsGuess = false;
        for (String i : jottoWordsList) { //looping through the word list
          if (nextGuessField.getText().equals(i)) { // if the word is found
            containsGuess = true; //set variable to true;
            break;
          }
        }
        if (nextGuessField.getText().equals(mysteryWord)) { //if they guessed the word
          JTextField correctWordText = new JTextField( "Jotto! You won in \n" + (wordsGuessedList.size()+1) + " guesses."); //tell them they won with how many guesses
          correctWordText.setBounds(400, 200, 150, 50);
          correctWordText.setFont(new Font("Dialog", Font.PLAIN, 10));
          
          //disable buttons/feilds
          guessWordButton.setEnabled(false);
          nextGuessField.disable();
          wordsGuessedArea.disable();
          guessesSoFarLabel.disable();
          giveUpButton.setEnabled(false);
          exceptions = true;

          frame.add(correctWordText);

        } else if (containsGuess == false) { //if it isn't  valid word
          JTextField invalidWordText = new JTextField("Not a valid word");
          invalidWordText.setBounds(400, 200, 150, 50);
          invalidWordText.setFont(new Font("Dialog", Font.PLAIN, 16));
          exceptions = true; // set variable to true so won't add word to list
          frame.add(invalidWordText);

        }
        for (String c : wordsGuessedList) {//loop through words guessed

          if (nextGuessField.getText().equals(c)) { // if they already guessed that word
            JTextField wordAlreadyGuessedText = new JTextField("You already guessed " + nextGuessField.getText());
            wordAlreadyGuessedText.setBounds(400, 200, 150, 50);
            wordAlreadyGuessedText.setFont(new Font("Dialog", Font.PLAIN, 10));
            exceptions = true;
            frame.add(wordAlreadyGuessedText);
          }

        }
        if (exceptions == false) { // if there was not exceptions
          lettersAccountedFor.clear();
          wordsGuessedList.add(nextGuessField.getText()); // add word to list
          //Find how any letters are in common
          for (int i = 0; i < nextGuessField.getText().length(); i++) {                      
            if(lettersAccountedFor.contains(nextGuessField.getText().charAt(i))){ //Check if the word has already been accounted for
              continue;
            }
            for (int j = 0; j < mysteryWord.length(); j++) {
               if (mysteryWord.charAt(j) == nextGuessField.getText().charAt(i)) { // if a letter is shared between the two words
                numberOfCorrectLetters++;
                lettersAccountedFor.add(nextGuessField.getText().charAt(i)); //Add that letter the already accounted for array list to make sure won't double count it
                //break;
              }
            }
          }

          guessesSoFar++; //Increase the guesses
          guessesSoFarLabel.setText("Guesses so far: " + guessesSoFar);
          wordsGuessedArea.append(nextGuessField.getText() + " " + numberOfCorrectLetters + "\n"); //Print the word and the number of corresponding letters
          numberOfCorrectLetters = 0;
        }
        nextGuessField.setText("");//reset the text feild

      }
    });
    
    frame.add(guessWordButton);

    //if enter is pressed after the game ends
    
    
    giveUpButton.setBounds(400, 425, 150, 50);
    giveUpButton.setFont(new Font("Dialog", Font.PLAIN, 18));
    giveUpButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        
        JTextField giveUpText = new JTextField("The secret word \nwas " + mysteryWord); //reveal word
        giveUpText.setBounds(400, 200, 150, 50);
        giveUpText.setFont(new Font("Dialog", Font.PLAIN, 10));
        frame.add(giveUpText);
        //disable buttons
        guessWordButton.setEnabled(false);
        nextGuessField.disable();
        wordsGuessedArea.disable();
        guessesSoFarLabel.disable();
        nextGuessField.disable();
        giveUpButton.setEnabled(false);
        

      }
    });
    // Adds button to frame

    frame.add(giveUpButton);

    
    //When you press enter the play again button will be activated
    playAgainButton.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent evt) {
        // VK_Enter is the key code for the ENTER key
        if (evt.getKeyCode() == VK_ENTER) {
     
          playAgainButton.doClick();
        }
      }
    });
    // The "Play Again" button
    playAgainButton.setBounds(400, 500, 150, 50);
    playAgainButton.setFont(new Font(playAgainButton.getFont().getName(), Font.PLAIN, 18));
    playAgainButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        //re-enable variables
        guessWordButton.setEnabled(true);
        nextGuessField.enable();
        wordsGuessedArea.enable();
        guessesSoFarLabel.enable();
        giveUpButton.setEnabled(true);
        giveUpButton.setEnabled(true);
        //reset counter
        wordsGuessedList.clear();
        guessesSoFar = 0;
        wordsGuessedArea.setText("");
        //Find new random word
        int randomIndex = (int) (Math.random() * 100000 % 12470);
        mysteryWord = jottoWordsList.get(randomIndex);
        System.out.println(mysteryWord);

      }
    });
    frame.add(playAgainButton);
  }

  /**
   * Creates the GUI.
   *
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    Main main = new Main();
  }
}