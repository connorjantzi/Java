## Rubric

| Description | 1 mark each| 
| --- | --- |
| File name in reverse order |1 |
| file in reverse order |0.5 |
| The algorithm is easy to follow. |1 |
| Proper file I/O is used effectively |1 |
| Algorithm is an effective way of solving this problem |1|
| Variable names are meaningful and easy to understand. |1 |
| Java conventions are followed. | 1|
| Line comments are present |1 |
| Line comments are used effectively. They describe program flow and are meaningful | 1|
| Proper spacing and structure |1 |
| Proper Javadocs documentation |1 |

Good. Fully reversed file, but the newline characters are missing! 

**Date and Time:** Nov 9, 2022

**Overall Score:**  10.5/11