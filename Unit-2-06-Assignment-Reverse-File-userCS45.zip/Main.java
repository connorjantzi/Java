//@author userCS45

//Include libraries
import java.io.*;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.FileWriter;
import java.util.Arrays;

class Main {
  /**
   * Takes a file and reverses the order and name
   * @param fileName 
   */
  public static void reverseFile(String fileName) throws IOException {
    try {
      //Reverse name 
      String newName = "";
      char letter;
      for (int i = 0; i < fileName.length() - 4; i++) { // Subtrat four to elminate .txt
        letter = fileName.charAt(i); //Reversing the word 
        newName = letter + newName; 
      }
      newName += ".txt"; //Put the rever word in a variable newName 

      FileWriter file = new FileWriter(newName); // Creating the new file

      BufferedWriter buffer = new BufferedWriter(file); // Writing to the file

      File file1 = new File(fileName); // Reading from the file

      Scanner scanner = new Scanner(file1); // Scanning file

      char[] array = new char[1000000]; //Create array to hold characters
      String token; //HOld each word 
      int totalCharacter = 0;

      while (scanner.hasNext()){ //while there is something to input

        array[totalCharacter] = 32; //Add spaces
        totalCharacter++; //Go onto the next character int eh array after adding a space

        token = scanner.next(); //Inputing the next word 
        
        for (int i = 0; i < token.length(); i++) { //Loop to input to array
          array[totalCharacter] = token.charAt(i); //put each token character in in array 
          totalCharacter++; //Go onto next character in array. 
        }
      }
      for (int i = array.length - 1; i >= 0; i--) { //Loop to print array to buffer in oposite order
        if (array[i] != (char) 0){ //While the array still has character in it. 
          buffer.write(array[i]); //Print to file
        }   
      }

      if (buffer != null) buffer.close(); //Close buffer
      scanner.close(); //Close scanner
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
    }

  }

  /**
   * Calls the function
   * 
   * @param args the command line arguments
   */
  public static void main(String[] args) throws IOException {
    try {
      reverseFile("romeoAndJuliet.txt"); //Tests
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
    }
  }
}
