/**
 * @author Zippy
 * @author userCS45
 */

//Libraries needed to run the memory game
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import static java.awt.event.KeyEvent.*;


//Create main that extends JFrame so we can create graphics
public class Main extends JFrame{
  //Initializing variables
  int xCoord = 0;
  int yCoord = 0;
  int numOfCardFlipCount = 0;

  ImageIcon possibleMatch;
  int[] possibleMatchCoords = new int[4];
  ImageIcon possibleMatchTwo;
  
  //Creating varaible for images
  ImageIcon kisses = new ImageIcon("Images/Kisses.jpg");
  ImageIcon backOfCard = new ImageIcon("Images/backofcard.png");
  ImageIcon cake = new ImageIcon("Images/Cake.jpg");
  ImageIcon iceCream = new ImageIcon("Images/IceCream.png");
  ImageIcon cookie = new ImageIcon("Images/Cookie.png");
  ImageIcon gummyBear = new ImageIcon("Images/Gummybear.png");
  ImageIcon aero = new ImageIcon("Images/aero.webp");
  ImageIcon cremeBrulee = new ImageIcon("Images/CremeBrulee.jpg");
  ImageIcon gummyWorm = new ImageIcon("Images/Gummyworm.png");
  ImageIcon mAndM = new ImageIcon("Images/MM.png");
  ImageIcon oreo = new ImageIcon("Images/Oreo.png");
  ImageIcon pie = new ImageIcon("Images/Pie.png");
  ImageIcon popsicle = new ImageIcon("Images/Popsicle.png");
  ImageIcon sucker = new ImageIcon("Images/Sucker.png");
  ImageIcon assasin = new ImageIcon("Images/Assassin.png");
  

  JFrame frame = new JFrame("Memory game");

  // The panel that has the instructions
  JPanel panel = new JPanel();

   // The 2D arrays of cards
  Card[][] boardCardEasy = new Card[2][2];
  Card[][] boardCardMedium = new Card[4][4];
  Card[][] boardCardHard = new Card[5][5];

  // Array list for numer of cards flipped
  ArrayList<ImageIcon> numberOfCardsFlipped = new ArrayList();
  //Array list to shuffle images
  ArrayList<ImageIcon> images = new ArrayList();

   // The 2D arrays of buttons
  JButton[][] boardButtonEasy = new JButton[2][2];
  JButton[][] boardButtonMedium = new JButton[4][4];
  JButton[][] boardButtonHard = new JButton[5][5];

  int cardsLeftEasy = 4; 
  int cardsLeftMedium = 16; 
  int cardsLeftHard = 25;
  int assasinClick = 0; 

  //Unique colours
  public static final Color VERY_LIGHT_BLUE = new Color(51,153,255);
  public static final Color DARK_YELLOW = new Color(255,204,0);	
  public static final Color VERY_LIGHT_RED = new Color(255-102-102);
  public static final Color DARK_GREEN = new Color(	
0,153,0);
  
  public Main (){
    //The instructions panel
    instructionsPanel();
    this.add(panel);
    this.setSize(800, 600);
    this.setResizable(false);
    this.setTitle("Memory Game");
    this.setLocationRelativeTo(null);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);

  }
  /**
   * Changes the panel to display the instructions for the game.
   */
  private void instructionsPanel(){
    panel.setLayout(null);
    panel.removeAll();
    
    // The "Continue" button
    JButton continueButton = new JButton();
    continueButton.setText("Continue");
    continueButton.setSize(200, 50);
    continueButton.setLocation(350, 450);
    continueButton.setForeground(Color.BLUE);
    continueButton.setBackground(Color.WHITE);
    continueButton.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent evt) {
        // VK_Enter is the key code for the ENTER key
        if (evt.getKeyCode() == VK_ENTER) {
          continueButton.doClick();
        }
      }
    });
    continueButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        setLevelPanel(evt);
      }
    });
    
    // The title
    JLabel rulesTitle = new JLabel("Memory Game Rules");
    
    rulesTitle.setSize(736, 100);
    rulesTitle.setLocation(200, 0);
    rulesTitle.setFont(new Font("Test", Font.PLAIN, 36));
    rulesTitle.setForeground(Color.WHITE);
    
    // The instructions
    JLabel rules1 = new JLabel();
    JTextArea rules2 = new JTextArea();
    JLabel rules3 = new JLabel();
    JTextArea rules4 = new JTextArea();
    
    rules1.setText("To Win:");
    rules2.setText("Find all of the matches.");
    rules3.setText("Gameplay:");
    rules4.setText("First select a level. \n\n");
    rules4.setText(rules4.getText() + "Pick two cards out of the cards displayed. Once you have looked at the \n");
    rules4.setText(rules4.getText() + "cards click 'Flip' to flip them back over.\n");
    rules4.setText(rules4.getText() + "If the cards are the same you have found a match. \n");
    rules4.setText(rules4.getText() + "Keep selecting cards until you have found all of the matches. \n\n");
    rules4.setText(rules4.getText() + "Once all of the matches are found you won! \n \n");
    
    rules1.setSize(736, 50);
    rules1.setLocation(25, 70);
    rules1.setBackground(Color.BLUE);
    rules1.setFont(new Font("Test", Font.PLAIN, 25));
    rules1.setForeground(Color.WHITE);
    
    rules2.setSize(736, 30);
    rules2.setLocation(25, 120);
    rules2.setBackground(Color.BLUE);
    rules2.setFont(new Font("Test", Font.PLAIN, 20));
    rules2.setForeground(Color.WHITE);
    rules2.setEditable(false);
    
    rules3.setSize(736, 50);
    rules3.setLocation(25, 150);
    rules3.setBackground(Color.BLUE);
    rules3.setFont(new Font("Test", Font.PLAIN, 25));
    rules3.setForeground(Color.WHITE);
    
    rules4.setSize(736, 300);
    rules4.setLocation(25, 200);
    rules4.setBackground(Color.BLUE);
    rules4.setFont(new Font("Test", Font.PLAIN, 20));
    rules4.setForeground(Color.WHITE);
    rules4.setEditable(false);
    
    // The background is blue
    panel.setBackground(Color.BLUE);
    
    // Adds the components to the panel
    panel.add(continueButton);
    panel.add(rulesTitle);
    panel.add(rules1);
    panel.add(rules2);
    panel.add(rules3);
    panel.add(rules4);

    panel.updateUI();
    this.add(panel);
  }
  /**
   * Changes the panel to display the levels for the game.
   * @param evt
   */
  private void setLevelPanel(ActionEvent evt) {
    panel.removeAll();
    //Set colour for the panel
    panel.setBackground(VERY_LIGHT_BLUE);

    // Pick a level title
    JLabel levelTitle = new JLabel("Pick a Level");

    levelTitle.setSize(736, 100);
    levelTitle.setLocation(275, 0);
    levelTitle.setFont(new Font("Test", Font.PLAIN, 36));
    levelTitle.setForeground(Color.WHITE);

    panel.add(levelTitle);

    // The "Easy" button
    JButton easyButton = new JButton();
    easyButton.setText("EASY\n");
    easyButton.setSize(200, 50);
    easyButton.setLocation(275, 150);
    easyButton.setForeground(Color.BLACK);
    easyButton.setBackground(DARK_GREEN);
    panel.add(easyButton);
    easyButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        easyGamePanel(evt); 
    
      }
    });
    
    // The "Medium" button
    JButton mediumButton = new JButton();
    mediumButton.setText("MEDIUM\n");
    mediumButton.setSize(200, 50);
    mediumButton.setLocation(275, 250);
    mediumButton.setForeground(Color.BLACK);
    mediumButton.setBackground(DARK_YELLOW);
    panel.add(mediumButton);
    mediumButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        mediumGamePanel(evt);
      }
    });
    // The "Hard" button
    JButton hardButton = new JButton();
    hardButton.setText("HARD");
    hardButton.setSize(200, 50);
    hardButton.setLocation(275, 350);
    hardButton.setForeground(Color.BLACK);
    hardButton.setBackground(Color.RED);
    panel.add(hardButton);
    hardButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        hardGamePanel(evt);
      }
    }); 
    //Recommended label
    JLabel recommended = new JLabel("Recommended Age\n\n");

    recommended.setSize(200, 300);
    recommended.setLocation(10, 15);
    recommended.setFont(new Font("Test", Font.PLAIN, 20));
    recommended.setForeground(Color.WHITE);
    panel.add(recommended);

    //Legend label
    JTextArea legend = new JTextArea();
    legend.setText(legend.getText() + "Easy: \nAges 2-6\n");
    legend.setText(legend.getText() + "Medium: \nAges 7-12 \n");
    legend.setText(legend.getText() + "Hard: \nAges 13+ ");

    legend.setSize(130, 190);
    legend.setLocation(50, 180);
    legend.setBackground(VERY_LIGHT_BLUE);
    legend.setFont(new Font("Test", Font.PLAIN, 18));
    legend.setForeground(Color.WHITE);
    panel.add(legend);

    JButton backButton = new JButton();
    backButton.setText("Back");
    backButton.setSize(150, 50);
    backButton.setLocation(40, 400);
    backButton.setForeground(VERY_LIGHT_BLUE);
    backButton.setBackground(Color.WHITE);
    panel.add(backButton);
    //Flip Button on enter
    backButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        //Go back to level selection
        instructionsPanel();
      }
    }); 
  }
  
  //EASY GAME PANEL
  /**
   * Changes the panel to display the easy board.
   * @param evt
   */
  private void easyGamePanel(ActionEvent evt){
    panel.removeAll();
    panel.setBackground(VERY_LIGHT_BLUE);
    numberOfCardsFlipped.clear();
    // Number of cards flipped counter label
    JLabel cardsFlippedCounter = new JLabel("Number of Cards Flipped: ");
    cardsFlippedCounter.setSize(736, 100);
    cardsFlippedCounter.setLocation(500,100);
    cardsFlippedCounter.setFont(new Font("Test", Font.PLAIN, 18));
    cardsFlippedCounter.setForeground(Color.WHITE);
    cardsFlippedCounter.setText(cardsFlippedCounter.getText() + numberOfCardsFlipped.size());
    panel.add(cardsFlippedCounter);

    //Game title for "Let's Play!"
    JLabel gamePlayTitle = new JLabel("Let's Play!");

    gamePlayTitle.setSize(736, 100);
    gamePlayTitle.setLocation(275, 0);
    gamePlayTitle.setFont(new Font("Test", Font.PLAIN, 36));
    gamePlayTitle.setForeground(Color.WHITE);

    panel.add(gamePlayTitle);

    //Instructions for the user what do do once the found a match
    JLabel checkAnswerInstructions = new JLabel("Also click 'Flip' once you found a match");

    checkAnswerInstructions.setSize(736, 100);
    checkAnswerInstructions.setLocation(10, 100);
    checkAnswerInstructions.setFont(new Font("Test", Font.PLAIN, 14));
    checkAnswerInstructions.setForeground(Color.WHITE);

    panel.add(checkAnswerInstructions);
    //Calles suffle array to shuffle the array
    shuffleEasy();
    // Create cards face down and assign images for the front of the cards
    boardCardEasy[0][0] = new Card(0,0,backOfCard, images.get(0), backOfCard);
    boardCardEasy[0][1] = new Card(0,1,backOfCard, images.get(1), backOfCard);
    boardCardEasy[1][0] = new Card(1,0,backOfCard, images.get(2), backOfCard);
    boardCardEasy[1][1] = new Card(1,1,backOfCard, images.get(3), backOfCard);

    //Back button to return to main menu
    JButton backButton = new JButton();
    backButton.setText("Back");
    backButton.setSize(150, 50);
    backButton.setLocation(70, 400);
    backButton.setForeground(VERY_LIGHT_BLUE);
    backButton.setBackground(Color.WHITE);
    panel.add(backButton);
    //Flip Button on enter
    backButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        //Go back to level selection
        setLevelPanel(evt);
      }
    }); 

    //Loop through buttons
    for(int i = 0; i < 2; i++) {
      for(int j = 0; j < 2; j++) {
        //Create buttons for each card
        JButton button = new JButton(); 
        
        // Adds button to the 2D array of buttons
        boardButtonEasy[i][j] = button;
        //Set the button to the back of the card
        button.setIcon(backOfCard);
        //Set size of cards
        button.setSize(100, 140);
        
        // Places the button at the correct location on the game board
        button.setLocation(100 * i + 288, 140 * j + 100);

        // Connects the action listener: cardPressedEasy()
        button.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent evt) {
          // Makes sure only two cards can be pressed at a time
           if(numOfCardFlipCount < 2){
             //Calles the card pressed function
            cardPressedEasy(evt);
             // Updates the cards flipped counter
            cardsFlippedCounter.setText("Number of Cards Flipped: " + numberOfCardsFlipped.size());
           }
            
          }
        });
        
        flipCardButton(2);
        
        panel.add(button);
      }
    }
  }
  
  //MEDIUM GAME PANEL
  /**
   * Changes the panel to display the medium level board.
   * @param evt
   */
  private void mediumGamePanel(ActionEvent evt){
    panel.removeAll();
    panel.setBackground(VERY_LIGHT_RED);
    //Clear the array list
    numberOfCardsFlipped.clear();
    //Creates the cards flipped counter label
    JLabel cardsFlippedCounter = new JLabel("Number of Cards Flipped: "); 
    cardsFlippedCounter.setSize(736, 100);
    cardsFlippedCounter.setLocation(20,300);
    cardsFlippedCounter.setFont(new Font("Test", Font.PLAIN, 18));
    cardsFlippedCounter.setForeground(Color.WHITE);
    cardsFlippedCounter.setText(cardsFlippedCounter.getText() + numberOfCardsFlipped.size());
    panel.add(cardsFlippedCounter);

    //Create the "Let's Play" label
    JLabel gamePlayTitle = new JLabel("Let's Play!");

    gamePlayTitle.setSize(736, 100);
    gamePlayTitle.setLocation(40, 0);
    gamePlayTitle.setFont(new Font("Test", Font.PLAIN, 36));
    gamePlayTitle.setForeground(Color.WHITE);

    panel.add(gamePlayTitle);

    //Instructions for the user what do do once the found a match
    JLabel checkAnswerInstructions = new JLabel("Click 'Flip' for next cards.");

    checkAnswerInstructions.setSize(736, 100);
    checkAnswerInstructions.setLocation(45, 100);
    checkAnswerInstructions.setFont(new Font("Test", Font.PLAIN, 14));
    checkAnswerInstructions.setForeground(Color.WHITE);

    panel.add(checkAnswerInstructions);

    //Back button to return to main menu
    JButton backButton = new JButton();
    backButton.setText("Back");
    backButton.setSize(150, 50);
    backButton.setLocation(70, 400);
    backButton.setForeground(VERY_LIGHT_BLUE);
    backButton.setBackground(Color.WHITE);
    panel.add(backButton);
    //Flip Button on enter
    backButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        //Go back to level selection
        setLevelPanel(evt);
      }
    }); 
    //Reset counter
    numOfCardFlipCount = 0; 
    //Calles the shuffle function to shuffle the cards
    shuffleMedium(); 
    
    // Create cards face down and assign images for the front of the cards
    boardCardMedium[0][0] = new Card(0,0,backOfCard, images.get(0), backOfCard);
    boardCardMedium[0][1] = new Card(0,1,backOfCard, images.get(1), backOfCard);
    boardCardMedium[0][2] = new Card(0,2,backOfCard, images.get(2), backOfCard);
    boardCardMedium[0][3] = new Card(0,3,backOfCard, images.get(3), backOfCard);
    
    boardCardMedium[1][0] = new Card(1,0,backOfCard, images.get(4), backOfCard);
    boardCardMedium[1][1] = new Card(1,1,backOfCard, images.get(5), backOfCard);
    boardCardMedium[1][2] = new Card(1,2,backOfCard, images.get(6), backOfCard);
    boardCardMedium[1][3] = new Card(1,3,backOfCard, images.get(7), backOfCard);
    
    boardCardMedium[2][0] = new Card(2,0,backOfCard, images.get(8), backOfCard);
    boardCardMedium[2][1] = new Card(2,1,backOfCard, images.get(9), backOfCard);
    boardCardMedium[2][2] = new Card(2,2,backOfCard,images.get(10) , backOfCard);
    boardCardMedium[2][3] = new Card(2,3,backOfCard, images.get(11), backOfCard);
    
    boardCardMedium[3][0] = new Card(3,0,backOfCard,images.get(12) , backOfCard);
    boardCardMedium[3][1] = new Card(3,1,backOfCard,images.get(13) , backOfCard);
    boardCardMedium[3][2] = new Card(3,2,backOfCard,images.get(14) , backOfCard);
    boardCardMedium[3][3] = new Card(3,3,backOfCard,images.get(15) , backOfCard);
    
    //Loop through the buttons
    for(int i = 0; i < 4; i++) {
      for(int j = 0; j < 4; j++) {
        //Create a button for each card
        JButton button = new JButton();
        
        // Adds button to the 2D array of buttons
        boardButtonMedium[i][j] = button;
        //Set the button to the back of the card
        button.setIcon(backOfCard); 
        button.setSize(100, 140);
        
        // Places the button at the correct location on the game board
        button.setLocation(100 * i + 288, 140 * j + 10);
        
        // Connects the action listener: cardPressedMedium()
        button.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent evt) {
            //Make sure only two cards are flipped over at one time
            if(numOfCardFlipCount < 2){
              //Call the function once the card is pressed
              cardPressedMedium(evt);
              //Update the counter for number of cards flipped
              cardsFlippedCounter.setText("Number of Cards Flipped: " + numberOfCardsFlipped.size());
            }
          }
        });
        //Call the function to flip the cards
        flipCardButtonMedium();
        panel.add(button);
      }
    }
  }
  
  //HARD GAME PANEL
  /**
   * Changes the panel to display the hard level game board.
    * @param evt
   */
  private void hardGamePanel(ActionEvent evt){
    panel.removeAll();
    panel.setBackground(VERY_LIGHT_RED);
    //Clear the flipper counter array list
    numberOfCardsFlipped.clear();
    //Creates the cards flipped counter label
    JLabel cardsFlippedCounter = new JLabel("Number of Cards Flipped: "); 
    
    cardsFlippedCounter.setSize(736, 100);
    cardsFlippedCounter.setLocation(20,300);
    cardsFlippedCounter.setFont(new Font("Test", Font.PLAIN, 18));
    cardsFlippedCounter.setForeground(Color.WHITE);
    cardsFlippedCounter.setText(cardsFlippedCounter.getText() + numberOfCardsFlipped.size());
    panel.add(cardsFlippedCounter);

    //Create the "let's play!" label
    JLabel gamePlayTitle = new JLabel("Let's Play!");

    gamePlayTitle.setSize(736, 100);
    gamePlayTitle.setLocation(40, 0);
    gamePlayTitle.setFont(new Font("Test", Font.PLAIN, 36));
    gamePlayTitle.setForeground(Color.WHITE);

    panel.add(gamePlayTitle);

    //Instructions for the user what do do once the found a match
    JLabel checkAnswerInstructions = new JLabel("Click 'Flip' if you found a match");

    checkAnswerInstructions.setSize(736, 100);
    checkAnswerInstructions.setLocation(45, 100);
    checkAnswerInstructions.setFont(new Font("Test", Font.PLAIN, 14));
    checkAnswerInstructions.setForeground(Color.WHITE);

    panel.add(checkAnswerInstructions);

    //Back button to return to main menu
    JButton backButton = new JButton();
    backButton.setText("Back");
    backButton.setSize(150, 50);
    backButton.setLocation(70, 400);
    backButton.setForeground(VERY_LIGHT_BLUE);
    backButton.setBackground(Color.WHITE);
    panel.add(backButton);
    //Flip Button on enter
    backButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        //Go back to level selection
        assasinClick = 0;
        numberOfCardsFlipped.clear(); 
        setLevelPanel(evt);
      }
    }); 
    //Reset variable
    numOfCardFlipCount = 0; 
    //Calles the shuffle function to shuffle the cards
    shuffleHard(); 
    // Create the cards face down and assign images for the front of the cards
    boardCardHard[0][0] = new Card(0,0,backOfCard, images.get(0), backOfCard);
    boardCardHard[0][1] = new Card(0,1,backOfCard, images.get(1), backOfCard);
    boardCardHard[0][2] = new Card(0,2,backOfCard, images.get(2), backOfCard);
    boardCardHard[0][3] = new Card(0,3,backOfCard, images.get(3), backOfCard);
    boardCardHard[0][4] = new Card(0,4,backOfCard, images.get(4), backOfCard);
    
    boardCardHard[1][0] = new Card(1,0,backOfCard, images.get(5), backOfCard);
    boardCardHard[1][1] = new Card(1,1,backOfCard, images.get(6), backOfCard);
    boardCardHard[1][2] = new Card(1,2,backOfCard, images.get(7), backOfCard);
    boardCardHard[1][3] = new Card(1,3,backOfCard, images.get(8), backOfCard);
    boardCardHard[1][4] = new Card(1,4,backOfCard, images.get(9), backOfCard);

    boardCardHard[2][0] = new Card(2,0,backOfCard,images.get(10), backOfCard);
    boardCardHard[2][1] = new Card(2,1,backOfCard,images.get(11), backOfCard);
    boardCardHard[2][2] = new Card(2,2,backOfCard,images.get(12), backOfCard);
    boardCardHard[2][3] = new Card(2,3,backOfCard,images.get(13), backOfCard);
    boardCardHard[2][4] = new Card(2,4,backOfCard,images.get(14), backOfCard);
    
    boardCardHard[3][0] = new Card(3,0,backOfCard,images.get(15) , backOfCard);
    boardCardHard[3][1] = new Card(3,1,backOfCard,images.get(16) , backOfCard);
    boardCardHard[3][2] = new Card(3,2,backOfCard,images.get(17) , backOfCard);
    boardCardHard[3][3] = new Card(3,3,backOfCard,images.get(18) , backOfCard);
    boardCardHard[3][4] = new Card(3,4,backOfCard,images.get(19), backOfCard);

    boardCardHard[4][0] = new Card(4,0,backOfCard,images.get(20) , backOfCard);
    boardCardHard[4][1] = new Card(4,1,backOfCard,images.get(21) , backOfCard);
    boardCardHard[4][2] = new Card(4,2,backOfCard,images.get(22) , backOfCard);
    boardCardHard[4][3] = new Card(4,3,backOfCard,images.get(23) , backOfCard);
    boardCardHard[4][4] = new Card(4,4,backOfCard, images.get(24), backOfCard);
    
    //Loop through all of the buttons
    for(int i = 0; i < 5; i++) {
      for(int j = 0; j < 5; j++) {
        //Create a button for each card
        JButton button = new JButton();
        
        // Adds button to the 2D array of buttons
        boardButtonHard[i][j] = button;
        //Set the cards to be face down
        button.setIcon(backOfCard); 
        button.setSize(100, 108); 
        
        // Places the button at the correct location on the game board
        button.setLocation(100 * i + 288, 108 * j + 10);

        button.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent evt) {
          //Ensure onyl two cards are flipped at a time
            if(numOfCardFlipCount < 2){
              cardPressedHard(evt);
              //Update the counter
              cardsFlippedCounter.setText("Number of Cards Flipped: " + numberOfCardsFlipped.size());
            }
          }
        });
        flipCardButtonHard();
        panel.add(button);
      }
    }
  }
  /**
   * Changes the panel to display the winning panel.
   * @param evt
   */
  private void winningGamePanel(ActionEvent evt){
    panel.removeAll();
    panel.setBackground(VERY_LIGHT_RED);

    //Congradualtions title
    JLabel congratsTitle = new JLabel("Congratulations! You won!");

    congratsTitle.setSize(736, 100);
    congratsTitle.setLocation(200, 0);
    congratsTitle.setFont(new Font("Test", Font.PLAIN, 36));
    congratsTitle.setForeground(Color.WHITE);
    panel.add(congratsTitle);

   // Displays the number of guesses it took to find all the matches
   JLabel numOfGuesses = new JLabel("You won in " + (numberOfCardsFlipped.size()/2));
    numOfGuesses.setText(numOfGuesses.getText() + " guesses!");
    numOfGuesses.setSize(350, 100);
    numOfGuesses.setLocation(250, 150);
    numOfGuesses.setFont(new Font("Test", Font.PLAIN, 26));
    numOfGuesses.setForeground(Color.WHITE);
    panel.add(numOfGuesses);   

     // The "Next" button
    JButton nextButton = new JButton();
    nextButton.setText("Next");
    nextButton.setSize(200, 100);
    nextButton.setLocation(300, 300);
    nextButton.setForeground(Color.BLUE);
    nextButton.setBackground(Color.WHITE);
    panel.add(nextButton);
    nextButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        endGamePanel(evt);
      }
    });
     
  }

  /**
   * Changes the panel to display the next options once the game has ended
   * @param evt
   */
  private void endGamePanel(ActionEvent evt){
    panel.removeAll();
    panel.setBackground(VERY_LIGHT_RED);
    //Resets variables
    cardsLeftEasy = 4;
    cardsLeftMedium = 16; 
    cardsLeftHard = 25;
    assasinClick = 0;
    numOfCardFlipCount = 0; 
    numberOfCardsFlipped.clear();

     // The "Play again" button
    JButton playAgain = new JButton();
    playAgain.setText("Play Again");
    playAgain.setSize(200, 50);
    playAgain.setLocation(350, 150);
    playAgain.setForeground(VERY_LIGHT_BLUE);
    playAgain.setBackground(Color.WHITE);
    panel.add(playAgain);
    playAgain.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        setLevelPanel(evt);
      }
    });
    
    // The "Quit" button
    JButton quit = new JButton();
    quit.setText("Quit");
    quit.setSize(200, 50);
    quit.setLocation(350, 350);
    quit.setForeground(VERY_LIGHT_BLUE);
    quit.setBackground(Color.WHITE);
    panel.add(quit);
    quit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        thanksForPlayingPanel();
      }
    });
   }

  /**
   * Changes the panel to display a message once the user has quit
   */
  private void thanksForPlayingPanel(){
    panel.removeAll();
    panel.setBackground(VERY_LIGHT_BLUE);

    //The "Back" button
    JButton backButton = new JButton();
    backButton.setText("Back");
    backButton.setSize(150, 50);
    backButton.setLocation(70, 400);
    backButton.setForeground(VERY_LIGHT_BLUE);
    backButton.setBackground(Color.WHITE);
    panel.add(backButton);
    //Flip Button on enter
    backButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        //Go back to tot he end game selection
        endGamePanel(evt);
      }
    }); 
    
    //Thanks for playing message
    JLabel thanksForPlaying = new JLabel();    
    thanksForPlaying.setText("Thanks for playing Memory Game\n");

    thanksForPlaying.setSize(736, 200);
    thanksForPlaying.setLocation(50, 0);
    thanksForPlaying.setFont(new Font("Test", Font.PLAIN, 36));
    thanksForPlaying.setForeground(Color.WHITE);

    panel.add(thanksForPlaying);
  }
  /**
     * Changes screen once the user has guessed the assassins twice
     */
  private void assasinGuessed(){
    panel.removeAll();
    panel.setBackground(Color.RED);

    //The "continue" button
    JButton continueButton = new JButton();
    continueButton.setText("Continue");
    continueButton.setSize(150, 50);
    continueButton.setLocation(300, 400);
    continueButton.setForeground(VERY_LIGHT_BLUE);
    continueButton.setBackground(Color.WHITE);
    panel.add(continueButton);
    //Flip Button on enter
    continueButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        //Go back to the end game selection panel
        endGamePanel(evt);
      }
    }); 

    //The messge once you guessed the assassin
    JLabel assasinMessage = new JLabel();
    assasinMessage.setText("Game Over! You guessed the assassin.");
    assasinMessage.setSize(736, 200);
    assasinMessage.setLocation(50, 0);
    assasinMessage.setFont(new Font("Test", Font.PLAIN, 36));
    assasinMessage.setForeground(Color.WHITE);
    assasinClick = 0;

    panel.add(assasinMessage);
  }

  /**
    * Flips the card from front to back and vise versa
    *@param sizeOfCardGrid
    */
  public void flipCardButton(int sizeOfCardGrid){
    //The "flip" button
    JButton flipButton = new JButton();
    flipButton.setText("FLIP");
    System.out.println("fliipy");
    flipButton.setSize(200, 50);
    flipButton.setLocation(50, 200);
    flipButton.setForeground(Color.BLACK);
    flipButton.setBackground(Color.WHITE);
    panel.add(flipButton);
    //Flip Button on enter
    flipButton.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent evt) {
        // VK_Enter is the key code for the ENTER key
        if (evt.getKeyCode() == VK_ENTER) {
          flipButton.doClick();
        }
      }
    });
    
    flipButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        numOfCardFlipCount = 0;
        //Check if the cards match
        checkCards(2); 
        //Check to determine if the game should end
        if (cardsLeftEasy<1){
          winningGamePanel(evt);
        }
        //Loop through cards
        for(int i = 0; i <sizeOfCardGrid; i++){
          for(int j = 0; j<sizeOfCardGrid; j++){
            //Check if the cards are currently flipped
            if(!boardCardEasy[i][j].image.equals(backOfCard)){
              //Flip the cards
              boardCardEasy[i][j].flipCard();
              //Set the icon to the new image 
              boardButtonEasy[i][j].setIcon(boardCardEasy[i][j].image);
            }
          }
        }
      }
    }); 
  }
  /**
     * Flips the card from front to back and vise versa
     */
  public void flipCardButtonMedium(){
    //The "Flip" button 
    JButton flipButton = new JButton();
    flipButton.setText("FLIP");
    System.out.println("fliipy");
    flipButton.setSize(200, 50);
    flipButton.setLocation(50, 200);
    flipButton.setForeground(Color.BLACK);
    flipButton.setBackground(Color.WHITE);
    panel.add(flipButton);
    flipButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        numOfCardFlipCount = 0;
        //Check if the cards match
        checkCards(4);
        //TO determine in the game should end 
        if (cardsLeftMedium<1){
          winningGamePanel(evt);
        }
        //Loop through cards
        for(int i = 0; i <4; i++){
          for(int j = 0; j<4; j++){
            //Check if the card is flipped
            if(!boardCardMedium[i][j].image.equals(backOfCard)){
              //Flip card
              boardCardMedium[i][j].flipCard();
              //Asssign that icon to the button
              boardButtonMedium[i][j].setIcon(boardCardMedium[i][j].image);
            }
          }
        }
      }
    }); 
  }
  /**
     * Flips the card from front to back and vise versa
     */
  public void flipCardButtonHard(){
    //The "Flip" button 
    JButton flipButton = new JButton();
    flipButton.setText("FLIP");
    flipButton.setSize(200, 50);
    flipButton.setLocation(50, 200);
    flipButton.setForeground(Color.BLACK);
    flipButton.setBackground(Color.WHITE);
    panel.add(flipButton);
    flipButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent evt) {
        //reset varible
        numOfCardFlipCount = 0;
        //Check if the cards match
        checkCards(5);
        //Check if the game should end
        if (cardsLeftHard <2){
          winningGamePanel(evt);
        }
        //Loop through cards
        for(int i = 0; i <5; i++){
          for(int j = 0; j<5; j++){
            //Check if the card is flipped
            if(!boardCardHard[i][j].image.equals(backOfCard)){
              //Flip cards
              boardCardHard[i][j].flipCard();
              //Asign that image
              boardButtonHard[i][j].setIcon(boardCardHard[i][j].image);
            }
          }
        }
      }
    }); 
  }
  /**
     * Check what button was pressed and if it could be a match
     * @param evt
     */
  private void cardPressedEasy(ActionEvent evt){
    //Update the counter
    numOfCardFlipCount++;
    //Get buttons
    JButton button = (JButton)evt.getSource();
    //Check what corrdinates were pressed
    if(button.getLocation().x == 288){
      xCoord = 0;
    } else if(button.getLocation().x == 388){
      xCoord = 1;
    }
    if(button.getLocation().y == 100){
      yCoord = 0;
    }else if(button.getLocation().y == 240){
      yCoord = 1;
    }   
    //Adding the image to the array of images and calling the flip function
    numberOfCardsFlipped.add(boardCardEasy[xCoord][yCoord].flipCard());

    //Check if the card is face up and check if it is the first or second card flipped
    if(numOfCardFlipCount == 1 && !(boardCardEasy[xCoord][yCoord].image.toString()).equals(backOfCard.toString())){
      //Assign that image to the temp variable 
      possibleMatch = boardCardEasy[xCoord][yCoord].image;
      possibleMatchCoords[0] = xCoord;
      possibleMatchCoords[1] = yCoord;
     //Check if it is the second card flipped 
    }else if (numOfCardFlipCount == 2 && !(boardCardEasy[xCoord][yCoord].image.toString()).equals(backOfCard.toString())){
      possibleMatchTwo = boardCardEasy[xCoord][yCoord].image;
      possibleMatchCoords[2] = xCoord;
      possibleMatchCoords[3] = yCoord;
    }
    //Set the icon accordingly 
    boardButtonEasy[xCoord][yCoord].setIcon(boardCardEasy[xCoord][yCoord].image);
    
  /**
  * Check what button was pressed and if it could be a match
  * @param evt
  */
  }
  private void cardPressedMedium(ActionEvent evt){
    //Update counter
    numOfCardFlipCount++;
    //Get buttons
    JButton button = (JButton)evt.getSource();
    //Find location of card pressed
    if(button.getLocation().x == 288){
      xCoord = 0;
    } else if(button.getLocation().x == 388){
      xCoord = 1;
    }
    else if(button.getLocation().x == 488){
      xCoord = 2;
    }
    else if(button.getLocation().x == 588){
      xCoord = 3;
    }
    if(button.getLocation().y == 10){
      yCoord = 0;
    }else if(button.getLocation().y == 150){
      yCoord = 1;
    }
    else if(button.getLocation().y == 290){
      yCoord = 2;
    } 
    else if(button.getLocation().y == 430){
      yCoord = 3;
    }
    //Add the image to the array of card flipped
    numberOfCardsFlipped.add(boardCardMedium[xCoord][yCoord].flipCard());
    //Check if the card is flipped and if the the first card flipped
    if(numOfCardFlipCount == 1 && !(boardCardMedium[xCoord][yCoord].image.toString()).equals(backOfCard.toString())){
      //Update temp variable 
      possibleMatch = boardCardMedium[xCoord][yCoord].image;
      possibleMatchCoords[0] = xCoord;
      possibleMatchCoords[1] = yCoord;
     //Check if the card is flipped and if the the second card flipped
    }else if (numOfCardFlipCount == 2 && !(boardCardMedium[xCoord][yCoord].image.toString()).equals(backOfCard.toString())){
      //Update variables
      possibleMatchTwo = boardCardMedium[xCoord][yCoord].image;
      possibleMatchCoords[2] = xCoord;
      possibleMatchCoords[3] = yCoord;
    }
    //Update icon
    boardButtonMedium[xCoord][yCoord].setIcon(boardCardMedium[xCoord][yCoord].image);
  }
  /**
  * Check what button was pressed and if it could be a match for the hard level
  * @param evt
  */
  private void cardPressedHard(ActionEvent evt){
    //Update counter
    numOfCardFlipCount++;
    JButton button = (JButton)evt.getSource();
    //The message when you click the assasin
    JLabel assasinClicked = new JLabel("DON'T CLICK THAT CARD!"); 
    assasinClicked.setSize(736, 200);
    assasinClicked.setLocation(20,210);
    assasinClicked.setFont(new Font("Test", Font.PLAIN, 18));
    assasinClicked.setForeground(Color.WHITE);
    panel.add(assasinClicked);
    //Set not visiable so can update when the assassin is pressed
    assasinClicked.setVisible(false);
    //Get location of button pressed
    if(button.getLocation().x == 288){
      xCoord = 0;
    } else if(button.getLocation().x == 388){
      xCoord = 1;
    }
    else if(button.getLocation().x == 488){
      xCoord = 2;
    }
    else if(button.getLocation().x == 588){
      xCoord = 3;
    }
    else if(button.getLocation().x == 688){
      xCoord = 4;
    }
    if(button.getLocation().y == 10){
      yCoord = 0;
    }else if(button.getLocation().y == 118){
      yCoord = 1;
    }
    else if(button.getLocation().y == 226){
      yCoord = 2;
    } 
    else if(button.getLocation().y == 334){
      yCoord = 3;
    }
    else if(button.getLocation().y == 442){
      yCoord = 4;
    }
    numberOfCardsFlipped.add(boardCardHard[xCoord][yCoord].flipCard());
    //If the card flipped was the assassin and it is the second time it was flipped
    if((boardCardHard[xCoord][yCoord].image.toString()).equals(assasin.toString()) && assasinClick > 0){
      assasinGuessed();
      //If it is the first time the assassin was flipped
    }else if ((boardCardHard[xCoord][yCoord].image.toString()).equals(assasin.toString())){
      //Set the assassin message to visiable 
      assasinClicked.setVisible(true);
      //Update the counter
      assasinClick++;
    }
    //If it is the first card flipped
    if(numOfCardFlipCount == 1 && !(boardCardHard[xCoord][yCoord].image.toString()).equals(backOfCard.toString())){
      possibleMatch = boardCardHard[xCoord][yCoord].image;
      possibleMatchCoords[0] = xCoord;
      possibleMatchCoords[1] = yCoord;
     //If it is the second card slipped
    }else if (numOfCardFlipCount == 2 && !(boardCardHard[xCoord][yCoord].image.toString()).equals(backOfCard.toString())){
      //Set variable
      possibleMatchTwo = boardCardHard[xCoord][yCoord].image;
      //Set coords
      possibleMatchCoords[2] = xCoord;
      possibleMatchCoords[3] = yCoord;
    }
    //Set icon
    boardButtonHard[xCoord][yCoord].setIcon(boardCardHard[xCoord][yCoord].image);
  }
  /**
  * Check if the cards are a match
  * @param sizeOfArray
  */
  private void checkCards(int sizeOfArray){
    //If the cards are a match
    if(possibleMatch.toString().equals(possibleMatchTwo.toString())){
      System.out.println("It works");
      //Check what level it is
      if(sizeOfArray == 2){
        removeCardsEasy();
      }else if(sizeOfArray == 4){
        removeCardsMedium();
      }else if(sizeOfArray == 5){
        removeCardsHard();
      }
    }
  }
  /**
  * Remove the matches for the easy level
  */
  private void removeCardsEasy(){
    //Lower counter by 2
    cardsLeftEasy = cardsLeftEasy-2; 
    //Remove cards
    boardButtonEasy[possibleMatchCoords[0]][possibleMatchCoords[1]].setVisible(false);
    boardButtonEasy[possibleMatchCoords[2]][possibleMatchCoords[3]].setVisible(false);
  }
  /**
  * Remove the matches for the medium level
  */
  private void removeCardsMedium(){
    //Decrease counter
    cardsLeftMedium = cardsLeftMedium-2; 
    //Remove cards
    boardButtonMedium[possibleMatchCoords[0]][possibleMatchCoords[1]].setVisible(false);
    boardButtonMedium[possibleMatchCoords[2]][possibleMatchCoords[3]].setVisible(false);
  }
  /**
  * Remove the matches for the hard level
  */
  private void removeCardsHard(){
    //Decrease counter
    cardsLeftHard = cardsLeftHard-2;
    //Remove cards
    boardButtonHard[possibleMatchCoords[0]][possibleMatchCoords[1]].setVisible(false);
    boardButtonHard[possibleMatchCoords[2]][possibleMatchCoords[3]].setVisible(false);
  }
  /**
  * Shuffle the cards for the easy level
  */
  void shuffleEasy() {
    Random random = new Random();
    //Clear array
    images.clear();
    //Add images to array list
    images.add(kisses);
    images.add(kisses);
    images.add(cake);
    images.add(cake);
    for (int i = images.size() - 1; i >= 1; i--) {
      // swapping current index value with random index value
      Collections.swap(images, i, random.nextInt(i + 1));
    }
  }
 /**
  * Shuffle the cards for the medium level
  */
  void shuffleMedium() {
    Random random = new Random();
    //Clear array
    images.clear();
    //Add images to array list
    images.add(kisses);
    images.add(kisses);
    images.add(iceCream);
    images.add(iceCream);
    images.add(cookie);
    images.add(cookie);
    images.add(gummyBear);
    images.add(gummyBear);
    images.add(gummyWorm);
    images.add(gummyWorm);
    images.add(oreo);
    images.add(oreo);
    images.add(popsicle);
    images.add(popsicle);
    images.add(sucker);
    images.add(sucker);
    
    for (int i = images.size() - 1; i >= 1; i--) {
      // swapping current index value
      // with random index value
      Collections.swap(images, i, random.nextInt(i + 1));
    }
}
  /**
  * Shuffle the cards for the hard level
  */
 void shuffleHard() {
    Random random = new Random();
    //Clear array
    images.clear();
   //Add images
    images.add(kisses);
    images.add(kisses);
    images.add(iceCream);
    images.add(iceCream);
    images.add(cookie);
    images.add(cookie);
    images.add(gummyBear);
    images.add(gummyBear);
    images.add(gummyWorm);
    images.add(gummyWorm);
    images.add(oreo);
    images.add(oreo);
    images.add(popsicle);
    images.add(popsicle);
    images.add(sucker);
    images.add(sucker);
    images.add(assasin);
    images.add(cremeBrulee);
    images.add(cremeBrulee);
    images.add(pie);
    images.add(pie);
    images.add(mAndM);
    images.add(mAndM);
    images.add(aero);
    images.add(aero);
    
    for (int i = images.size() - 1; i >= 1; i--) {
      //wapping current index value with random index value
      Collections.swap(images, i, random.nextInt(i + 1));
    }
  } 
  
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    Main memoryGame = new Main();
  }  
}