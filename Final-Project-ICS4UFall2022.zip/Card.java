/**
 *
 * @author Zippy05
* @author userCS45
 */

import javax.swing.ImageIcon;

public class Card {
  int xCoord;
  int yCoord;
  ImageIcon image; 
  ImageIcon front;
  ImageIcon back; 
    
  /**
  * 
  * @param xCoord the x-coordinate of the piece
  * @param yCoord the y-coordinate of the piece
  * @param current image of card
  * @param front of card
  * @param back of card
  */
  public Card(int xCoord, int yCoord, ImageIcon image, ImageIcon front, ImageIcon back) {
    this.xCoord = xCoord;
    this.yCoord = yCoord;
    this.image = image;
    this.front = front;
    this.back = back; 
    
  }
    
  /**
  * Flips the card from fron to back or vise versa.
  * @Return current image on card
  */
  public ImageIcon flipCard() {
    //If the card is face up
    if (this.image.equals(front)) {
      this.image = back;
      //If the card is face down
    } else if (this.image.equals(back)){
      this.image = front;
      //Otherwise set the card to be face down 
    } else{
      this.image = back;
    }
    //Return current image on card
    return image;
      
  }  
}