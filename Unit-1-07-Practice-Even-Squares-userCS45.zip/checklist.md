## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The method prints all the even squares inclusively between `n` and `m`.
✓ If `m` is less than `n`, it prints nothing.
✓ Test include a variety of cases such as base cases (e.g. when `n == m`) and edge cases (e.g. when `n` and/or `m` are even squares).
✓ All other custom methods are documented using Javadocs conventions.
✓ The program runs without any errors.
✓ The program is reasonably efficient (e.g. no triple-nested loops).
✓ The lines of code are indented correctly based on where they are placed.
✓ Line comments are effectively used.
✓ Java conventions are followed.