/**
 * @author userCS45
 */

public class Main {
  
  /**
   * Takes two integers, n and m, and prints all the even square numbers inclusively between n and m.
   * 
   * @param n any positive integer
   * @param m any integer greater than or equal to n
   */
  public static void evenSquares(int n, int m) {
    if (m>=n){ //If the first integer is greater than the second.  
      for(int possibleNumbers = n; possibleNumbers <= m; possibleNumbers++){ // looping until we have acount for all the square roots up to m. 
        double squareRoot = Math.sqrt(possibleNumbers); // Taking the square root.  
        if((squareRoot % 1) == 0){ //Check if it is a even sqrt.
          System.out.println(possibleNumbers + " "); //Print the square roots. 
        }
      }
    }else{
      System.out.println(0);
      return;
    }
    return; 
  }

  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    System.out.println("Even Squares:");
    evenSquares(100, 100);
    System.out.println("Even Squares:");
    evenSquares(63, 200);
    System.out.println("Even Squares:");
    evenSquares(8, 80);
    }
}
