## Rubric

| Description | 1 mark each | 
| --- | --- |
| All twelve pre-made tests pass. | 6/6|
| The algorithm for determine magic squares works. | 1|
| Conditional and loop structures are used effectively. | 1|
| Variable names are meaningful and easy to understand. |1 |
| Java conventions are followed. |1 |
| Line comments are used effectively. |1 |
| Magic Formula Referenced if used | 1|

**Date and Time:**

**Overall Score:**  12/12
