
/**
 *
 * @author userCS45
 */

import java.util.Arrays;

public class Main {
  /**
   * Takes in array and returns the count of the row
   *
   * @param row
   * @return int
   */

  private static int sumOfRow(int[] row) {
    int sum = 0;
    for (int i : row) { // Loop through array
      sum += i; //Add to count
    }
    return sum;
  }

  /**
   * Takes a 2-dimensional array of integers and determines whether it is a magic
   * square.
   *
   * @param matrix
   * @return boolean
   */
  public static boolean isMagicSquare(int[][] matrix) {
    //Didn't use magic formula
    // Check if 1 to n^2
    boolean checkForNumbers[] = new boolean[matrix[0].length * matrix[0].length]; // array of booleans to check if 1 to n^2
    if (matrix[0][0] == 0) { // if zero
      return false;
    }
    for (int i = 0; i < checkForNumbers.length; i++) {
      checkForNumbers[i] = false; // Set array to false
    }
    // Loop through matrix
    for (int i = 0; i < matrix.length; i++) {
      for (int j = 0; j < matrix[i].length; j++) { // loop through matrix
        if (matrix[i][j] > checkForNumbers.length) { // Check if number is greater thatn the n^2
          return false;
        }
        checkForNumbers[matrix[i][j] - 1] = true; // Set boolean at the array index to true if in the matrix contains that number
      }
    }
    // Check array if all element are true
    for (int i = 0; i < checkForNumbers.length; i++) {
      if (checkForNumbers[i] == false) { // If doesn't contain all number from 1 to n^2
        return false;
      }
    }

    // Check if square matrix
    for (int i = 0; i < matrix.length; i++) {
      if (matrix.length == matrix[i].length) {
      } else {
        return false;
      }
    }
    int n = sumOfRow(matrix[0]); // Finding n value

    for (int[] row : matrix) { // Loop through rows
      int sum = sumOfRow(row); // Find sum of rows
      if (sum != n) { // Checking if the sum if equal to n
        return false;
      }
    }

    int sum = 0; // Set sum to zereo
    for (int i = 0; i < matrix.length; i++) { // Looping through matrix column
      sum += matrix[i][i]; // Add numbers to sum
    }
    if (sum != n) { // Check if sum is equal to n
      return false;
    }

    sum = 0; // Set sum to zero
    for (int i = 0; i < matrix.length; i++) { // Looping through matrix
      sum += matrix[i][matrix.length - 1 - i]; // Check diagonals for correct sum
    }
    if (sum != n) { // Check if sum is correct
      return false;
    }
    return true; // If none of the other cases are false then return true.
  }

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    /*
     * Runs the twelve pre-made tests.
     *
     * You can comment out the line below out if you don't want these tests to run.
     */
    UnitTests.runTests();
  }
}
