## Rubric

| Description | 1 mark each| 
| --- | --- |
| Proper sum is calculated | |
| Program stops when q is entered | |
| The algorithm is easy to follow. | |
| Proper user I/O is used effectively | |
| Output matches example perfectly | |
| Algorithm is an effective way of solving this problem ||
| Variable names are meaningful and easy to understand. | |
| Java conventions are followed. | |
| Line comments are present | |
| Line comments are used effectively. They describe program flow and are meaningful | |
| Proper spacing and structure | |
| Javadocs documentation added perfectly | |

**Date and Time:** Oct 28 6pm

**Overall Score:**  12/12
