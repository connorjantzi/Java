/**
*@author userCS45
*/
import java.util.Scanner; // Import the Scanner class
class Main {
  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);//Open scanner
    System.out.println("Enter a series of integers. Press 'q' to quit."); //Displaying test
    int sum = 0; //Creating the sum variable
    while(true){ //Looping
      if(scanner.hasNextInt() == true){ //Checking is the user input is an integer. 
        sum += scanner.nextInt(); //Add the user input to the sum
        
      }else if(scanner.next().equals("q")){ //If the input is equal to q. 
        scanner.nextLine(); //Moves scanner to next line and returns input
        System.out.println("The total is " + sum); //Print total sum
        break; //End loop. 
      }else{ //If the input is wrong
        scanner.nextLine(); //Moves scanner to next line and return input
        System.out.println("Error, wrong input."); //Error message 
      }  
    }
    scanner.close(); //Close scanner
  }
}