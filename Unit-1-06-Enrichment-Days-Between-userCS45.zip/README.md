## Instructions

Complete the method `daysBetween()` according to its specifications.

**Hint 1:** Look up how to use the `Calendar` class.

**Hint 2:** You can use Wolfram|Alpha to check your answer. (Example: https://www.wolframalpha.com/input/?i=days+between+jan+1%2C+1990+and+nov+16%2C+2020)

## Main.java

Here is the original code in *Main.java* for reference:

```java
/**
 * @author name
 */

public class Main {
  
  /**
   * Determines the number of days between two dates.
   * The dates are in the format yyyy-mm-dd.
   *
   * @param date1
   * @param date2
   * @return int
   */
  public static int daysBetween(String date1, String date2) {
    /*
     * What goes here?
     */
    return 0;
  }

  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    /*
     * Create your own tests here.
     */
  }
}
```
