/**
 * @author userCS45
 */
//Including the required libraries.
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
public class Main {
  
  /**
   * Determines the number of days between two dates.
   * The dates are in the format yyyy-mm-dd.
   *
   * @param date1
   * @param date2
   * @return int
   */
  public static int daysBetween(String date1, String date2) {
    
    //Parsing the date
	  LocalDate firstDate= LocalDate.parse(date1);
	  LocalDate secondDate = LocalDate.parse(date2);
		
	  //Calculating number of days in between
	  long numOfDaysBetween = ChronoUnit.DAYS.between(firstDate, secondDate);
    
    int daysBetween=(int)numOfDaysBetween; //Converting long to int
    
    daysBetween = Math.abs(daysBetween); //Finding the absolute value of the days between so won't return a negative number. 
    return daysBetween; // Returning the number of days between the two dates. 
  }

  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    //Tests
    System.out.println(daysBetween("2022-02-24", "2019-07-02"));
    System.out.println(daysBetween("1992-11-15", "2010-05-17"));
    System.out.println(daysBetween("2006-06-15", "2006-11-11"));
    System.out.println(daysBetween("2019-07-27", "2011-09-04"));
    System.out.println(daysBetween("2013-01-19", "2013-01-24"));
  }
}
