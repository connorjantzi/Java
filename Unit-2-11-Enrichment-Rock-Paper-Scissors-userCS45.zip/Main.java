import java.util.Scanner; // Import the Scanner class
class Main {
//NEWFUNCTION FOR RAN NUM??
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double computerChoice = (Math.floor(Math.random() * 3) + 1);
    System.out.println("Let's play Rock Paper Scissors");
    System.out.println("Enter 1 for rock, 2 for paper, 3 for scissors.");
    System.out.println("It's best two out of three");
    System.out.println("What do you choose? "); 
    //scanner.nextInt(); 
    if(scanner.nextInt() == 1){
      if(computerChoice == 1){
        
      }else if(computerChoice == 2){
        
      }else if (computerChoice == 3){
        
      }
    }else if(scanner.nextInt() == 2){
      if(computerChoice == 1){
        
      }else if(computerChoice == 2){
        
      }else if (computerChoice == 3){
        
      }
    }else if(scanner.nextInt() == 3){
      if(computerChoice == 1){
        
      }else if(computerChoice == 2){
        
      }else if (computerChoice == 3){
        
      }
    } else{
      System.out.println("Please enter valid number");
    }
    
    
  }
  scanner.close(); 
}