## Instructions

Create a rock, paper, scissors game where the user plays against the randomly generated computer choices. You can make this as complex or as simple as you'd like, as long as it resembles a rock, paper, scissors game. 

Your output could be something like this:


Let's Play Rock Paper Scissors
Enter 1 for Rock, 2 for paper, 3 for scissors
It's best 2 out of 3, so let's see who wins
1
You Win! I used Scissors
2
I Win! I used Scissors
3
You Win! I used Paper
3
You Win! I used Paper
You win with 3, I had 1


Include all the Javadoc documentation just like the previous assignments, this time you just have to write it on your own:
* `@author` tag at the top of the file
* Method documentation for each method:
  *  A brief description of what the method does.
  * `@param` tag (if applicable)
  * `@return` tag (if applicable)
* Line comments within methods to explain your thinking