class Main {

  public static void functionTransformer(double []xValues, double [] yValues, double[] transformations){
    System.out.println("OUTPUT");
    for(int i = 0; i < xValues.length; i++){ //looping through array
      xValues[i] = xValues[i] / transformations[1] + transformations[3]; //Tranformations for x values
      System.out.print("X: " + xValues[i]);
      yValues[i] = yValues[i] * transformations[0] + transformations[2]; //Transformation for y values
      System.out.println(" Y: " + yValues[i]);
    }
  }
  
  public static void main(String[] args) {
    //test
    double []functionOneXValues = new double[]{2.0, 5.0, 7.0, 8.0};
    double []functionOneYValues = new double[]{-1.0, 3.0, 4.0, 6.0};
    double []functionOneTransformations = new double[]{2,2,-3,1}; //Order for transformations: a,k,c,d
    
    functionTransformer(functionOneXValues, functionOneYValues, functionOneTransformations); 
  }
}