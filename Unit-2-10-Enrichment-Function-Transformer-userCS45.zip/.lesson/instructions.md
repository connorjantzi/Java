## Instructions

Create a method called `functionTransformer()` that takes an array of coordinates (it's up to you how these are stored) and values for `a`, `k`, `d`, and `c` representing the transformation values in the function *f(x) = af(k(x - d)) + c* and returns the array of image coordinates according to the mapping (x, y) ↦ (x/k + d, ay + c). 


For example, if the input is the following table of values:


| x | y |
| -- | -- |
| 2 | -1 |
| 5 | 3 |
| 7 | 4 |
| 8 | 6 |


and the transformation values are `a = k = 2`, `d = 1`, `c = - 3`, then the output is:


| x | y |
| -- | -- |
| 2 | -5 |
| 3.5 | 3 |
| 4.5 | 5 |
| 5 | 9 |




Include all the Javadoc documentation just like the previous assignments:
* `@author` tag at the top of the file
* Method documentation for each method:
  *  A brief description of what the method does.
  * `@param` tag(s) (if applicable)
  * `@return` tag (if applicable)
  * `@throws` tag (if applicable)
* Line comments within methods to explain your thinking