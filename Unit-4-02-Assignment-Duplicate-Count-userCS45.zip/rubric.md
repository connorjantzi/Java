## Rubric

| Description | 1 mark each | 
| --- | --- |
| The algorithm for finding the duplicate count works. | |
| Variable names are meaningful and easy to understand. | |
| All ten tests pass. | /5|
| Java conventions are followed. | |
| Line comments are used effectively. | |

**Date and Time:**

**Overall Score:** 9/9
