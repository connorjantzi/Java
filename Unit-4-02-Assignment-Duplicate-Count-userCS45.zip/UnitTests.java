/**
 *
 * @author MissStrong
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class UnitTests {
  /**
   * This method runs the ten tests. 
   *
   * When a test passes, it prints a statement 
   * indicating it passed.
   *
   * When a test does not pass, it prints a statement 
   * indicating that it did not pass.
   */
  public static void runTests() {
    List<Integer> list1 = new ArrayList();
    List<Integer> list2 = new ArrayList(Arrays.asList(8));
    List<Integer> list3 = new ArrayList(Arrays.asList(1, 2, 3, 4, 5, -4, -3, -2));
    List<Integer> list4 = new ArrayList(Arrays.asList(-15, -15));
    List<Integer> list5 = new ArrayList(Arrays.asList(-5, 5, 5));
    List<Integer> list6 = new ArrayList(Arrays.asList(-10, -10, -10));
    List<Integer> list7 = new ArrayList(Arrays.asList(6, 6, 6, 0));
    List<Integer> list8 = new ArrayList(Arrays.asList(-1, -1, 0, 0));
    List<Integer> list9 = new ArrayList(Arrays.asList(-10, -10, 10, 10, 10, 8));
    List<Integer> list10 = new ArrayList(Arrays.asList(-2, 5, -2, 3, 6, 3, 6, 6, 5));

    List<ArrayList<Integer>> tests = new ArrayList(Arrays.asList(list1, list2, list3, list4, list5, list6, list7, list8, list9, list10));

    int[] solutions = {0, 0, 0, 1, 1, 1, 1, 2, 2, 4};

    for (int i = 0; i < 10; i++) {
      try {
        if (Main.duplicateCount(tests.get(i)) == solutions[i]) {
          System.out.println(String.format("Test %d passed!", i + 1));
        } else {
          System.out.println(String.format("Test %d did NOT pass. ", i + 1));
        }
      } catch (Exception e) {
        System.out.println(String.format("Test %d did NOT pass. ", i + 1));
      }
    }
  }
}
