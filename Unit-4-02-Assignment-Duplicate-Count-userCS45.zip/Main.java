/**
 *
 * @author userCS45
 */

import java.util.ArrayList;
import java.util.HashSet; 

public class Main {
    
  /**
   * Takes an arraylist of integers and returns the number
   * of unique items that appear more than once in the arraylist.
   * 
   * @param list an arraylist of integers
   * @return the number of unique items that are duplicates
   */
  public static int duplicateCount(ArrayList<Integer> list) {
    HashSet<Integer> duplicatesCount = new HashSet(); //HashSet that can be used to count the duplicates
    HashSet<Integer> possibleDuplicates = new HashSet(); //Hashset to store possible duplicates
    for(int i: list){ //loop through array
      if(possibleDuplicates.add(i) == false){ //Check if the numeber already exsist in array
        duplicatesCount.add(i); //add that number to the duplicates count
      }else{
      possibleDuplicates.add(i);//Add number to check if it will be seen again
      }
    }
    return duplicatesCount.size();//Reutnr the size fo the duplicate array to see the numebr of duplicates
  }
      
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    UnitTests.runTests();
  }    
}
