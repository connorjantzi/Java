/**
 *
 * @author userCS45
 */
import java.util.Arrays; //Import array library

public class Main {
  /*
   * Take a character and the string and determines how many times it occurs in the string
   * @param s 
   * @return char
   */
  public static int frequencyCount(int character, String s){
    int count = 0; //variable to count number of times occurs
    for(int i = 0; i < s.length(); i++){ //looping through the string
      if(s.charAt(i) == character){ //if the character occurs
        count++; //Increase the count; 
      }
    }
    return count; //Return thre numebr of times the character value occurs in the string
  }
  
  /**
   * This method takes a string and returns the least common character in it.
   *
   * If there is a tie, it returns the one at the highest index.
   *
   * If the string is empty, it returns the character with ASCII value 0.
   *
   * @param s 
   * @return char
   */
  public static char leastCommonChar(String s) {
    int []frequencyCounter = new int[s.length()]; //Array that goes through the string and counts. 
    int count; 
    int currentlyLowestCount = s.length(); 
    if(s.isEmpty() ){ //If the string is empty
      return (char)0;
    }
    else{
      
      int leastCommon =  s.charAt(0);  //Set lest common character variabe to the first character in string. 
      for(int i = 0; i < s.length(); i++){//Run through string. 
        
        frequencyCounter[i] = s.charAt(i); //Set the current character to a value in the array
        count = frequencyCount(frequencyCounter[i],s); //Sttt count varable to the count determined in the frequency count function. 
        if(count <= currentlyLowestCount){ //if the count is lowest than the currently lowest count, or if it is a tie it will late the one witht he latest index in the string. 
          leastCommon = frequencyCounter[i]; //set leason common character to the current chracter analized 
          currentlyLowestCount = count; //set the lowest count to the current count of the variable anylized 
        }
      }
      return (char)leastCommon; //reaturn the least common character at the highest index in the string. 
    }
  }
       
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    //Tests
     System.out.println("Least Common: \"" + leastCommonChar(" ") + "\"");
     System.out.println("Least Common: \"" + leastCommonChar("")+ "\"");
    System.out.println("Least Common: \"" + leastCommonChar("I am the Best, Obviously")+ "\"");
    System.out.println("Least Common: \"" + leastCommonChar("This is the best song every made in the world!!!!!!!!!!")+ "\"");
    System.out.println("Least Common: \"" + leastCommonChar("aaaaaaaapples are YUMMY didn't you know??")+ "\"");
  }   
}
