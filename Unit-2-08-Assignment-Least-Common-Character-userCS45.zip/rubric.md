## Rubric

| Description | 1 mark each | 
| --- | --- |
| The algorithm for finding the least common character works. | 1|
| The method gives the correct output when there is a tie. |1 |
| The method gives the correct output when the string is empty. |1 |
| The algorithm is easy to follow. |1 |
| Conditional structures are used effectively. |1 |
| Loop structures are used effectively. |1 |
| Variable names are meaningful and easy to understand. |1 |
| A wide variety of test cases are included. |1 |
| Java conventions are followed. |1 |
| Line comments are used effectively. |1 |

Just from reading the test case strings, I thought that this was Tyler's code... yep

**Date and Time:**

**Overall Score:** 10/ 10
