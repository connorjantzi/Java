## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The method implements the union of `setA` and `setB` correctly.
✓The method does not mutate the arguments `setA` and `setB`.
✓ All five tests pass.
✓ Java conventions are followed.
✓ Line comments are used effectively.
