/**
 *
 * @author userCS45
 */

import java.util.HashSet;

public class Main {
    
  /**
   * Takes two hashsets of integers and determines whether 
   * they have any items in common by checking whether 
   * |setA| + |setB| = |setA ∪ setB|.
   * 
   * @param setA
   * @param setB
   * @return true if setA and setB have at least item in common; false otherwise
   */
  public static boolean haveCommonItems(HashSet<Integer> setA, HashSet<Integer> setB) {
     HashSet<Integer> addedTogether = new HashSet (setA); 
    
    for(int row: setB){
      addedTogether.add(row); 
    }
    if(setA.size() + setB.size() == addedTogether.size()){ 
      return false;
    }else{
      return true; 
    }
  }
      
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
     UnitTests.runTests();
  }    
}
