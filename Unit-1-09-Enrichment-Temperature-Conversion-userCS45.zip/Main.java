/**
 * @author userCS45
 */


public class Main {
  
  /**
   * Converts a temperature from Celsius to Farenheit.
   *
   * @param t
   * @return double
   */
  public static double celsiusToFarenheit(double t) {
    return ((9*t)/5)+32; //Celsius to farenheit formula
  }


  /**
   * Converts a temperature from Farenheit to Celsius.
   *
   * @param t
   * @return double
   */
  public static double farenheitToCelsius(double t) {
    return (t-32)*5/9; //Farenheit to celsius formula. 
  }


  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    /*
    * Print test and round the answer.
    */
    System.out.println(Math.round(celsiusToFarenheit(23.5)));
    System.out.println(Math.round(celsiusToFarenheit(5.5)));
    System.out.println(Math.round(farenheitToCelsius(64.5)));
    System.out.println(Math.round(farenheitToCelsius(78.0)));
  }
}