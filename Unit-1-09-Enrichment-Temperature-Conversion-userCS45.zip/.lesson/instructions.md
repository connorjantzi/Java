## Instructions

Complete the methods `celsiusToFarenheit()` and `farenheitToCelsius()` according to their specifications.


**Hint:** Look up how to convert from Celcius to  Farenheit and vice versa.


## Main.java


Here is the original code in *Main.java* for reference:


```java
/**
 * @author name
 */


public class Main {
  
  /**
   * Converts a temperature from Celsius to Farenheit.
   *
   * @param t
   * @return double
   */
  public static double celsiusToFarenheit(double t) {
    /*
     * What goes here?
     */
    return 0.0;
  }


  /**
   * Converts a temperature from Farenheit to Celsius.
   *
   * @param t
   * @return double
   */
  public static double farenheitToCelsius(double t) {
    /*
     * What goes here?
     */
    return 0.0;
  }


  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    /*
     * Create your own tests here.
     */
  }
}