/**
@author userCS45
*/

import java.util.Scanner;  // Import the Scanner class

class Main {
  /**
  This program takes a string password input and returns an ecrypted version in the form: ******

  @oaran String password
  @return String encrypted password 
  */
  public static String encrypt(String password){
    int length =  password.length(); 
    password = "";
    for (int i = 0; i<length; i++){
      password += "*"; 
    }
    return password;
  }

  /**
  Main

  @param command line args
  @return void
  */
  public static void main(String[] args) {
    //Opening the scanner
    Scanner keyboard = new Scanner(System.in);
    //Create variables
    String username = "";
    String password = "";
    //Asking for username
    System.out.print("Username: ");
    username = keyboard.nextLine();
    //Asking for password. 
    System.out.print("Password: ");
    password = keyboard.nextLine();
    //Printing username
    System.out.println("Username: " + username);
    //Printing encrpyted passrod by calling the funtion. 
    System.out.println("Password: " + encrypt(password)); 
    
    keyboard.close(); 
  }
}