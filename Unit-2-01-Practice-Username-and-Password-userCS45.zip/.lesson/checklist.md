## Checklist

Check to make sure all instructions were followed before submitting this assignment.

✓ The method `encrypt()` correctly converts the password to encrypted * format.
✓ Scanner is opened and closed properly. 
✓ User input is correctly taken and stored using the scanner.
✓ The program runs without any errors.
✓ The lines of code are indented correctly based on where they are placed.
✓ Line comments are effectively used.
✓ Java conventions are followed.