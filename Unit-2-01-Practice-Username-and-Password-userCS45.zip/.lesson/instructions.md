## Instructions

Write a program that asks a user to input their username and password then prints the username and an encrypted password in **'s. The number of stars should match the length of their password. 

The output should look like this:

Username:
mscanning

Password:
password

Username:
mscanning

Password:
**

The original code in main.java is:

```java

/**
@author name
*/

import java.util.Scanner;  // Import the Scanner class

class Main {
  /**
  This program takes a string password input and returns an ecrypted version in the form: ******

  @oaran String password
  @return String encrypted password 
  */
  public static String encrypt(String password){
    /*
    * What goes here?
    */

    return "";
  }

  /**
  Main

  @param command line args
  @return void
  */
  public static void main(String[] args) {
    /*
    * What goes here?
    */
  }
}