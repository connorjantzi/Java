/**
 * @author userCS45
 */

public class Main {

  /**
   * Calculates whether *year* is a leap year.
   *
   * @param year
   * @return boolean
   */
  public static boolean isLeapYear(int year) {
    
    if (year % 4 == 0) { // If the leap year is divisible (using mod) by 4 then it may be a leap year.
      if (year % 100 == 0) { //Check if it is a century by dividing it by 100, this if after it is evenly divisible by 4.  

        if (year % 400 == 0) { //Check is it is evenly divisible by 400, this is after it is evenly divisible by 4 and 100. 
          return true;
          
        } else { // Otherwise it is not a leap year. 
          return false;
        }
        
      } else { // If it is not divisible by 100 but is by 4 then it is a leap year as well.  
        return true; 
      }
      
    } else { // Otherwise it is not a leap year if it isn't evenly divisble by 4. 
      return false;
    }
  }

  /**
   * Generates a string to indicate a leap year or non-leap year.
   *
   * @param bool
   * @return String
   */
  public static String leapYearString(boolean bool) {
    return bool ? "is a leap year." : "is NOT a leap year.";
  }

  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    System.out.println("2020 " + leapYearString(isLeapYear(2020)));
    System.out.println("2019 " + leapYearString(isLeapYear(2019)));
    System.out.println("2000 " + leapYearString(isLeapYear(2000)));
    System.out.println("1992 " + leapYearString(isLeapYear(1992)));
    System.out.println("1900 " + leapYearString(isLeapYear(1900)));
  }
}