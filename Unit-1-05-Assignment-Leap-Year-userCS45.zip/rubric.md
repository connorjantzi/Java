## Rubric

| Description | 1 mark each | 
| --- | --- |
| The algorithm is correct. |1 |
| The algorithm is easy to follow. |1 |
| Conditional structures are used effectively. |1 |
| Variable names are meaningful and easy to understand. |1 |
| All five examples works. |1 |
| Java conventions are followed. |1 |
| Line comments are present |1 |
| Line comments are used effectively. They describe program flow and are meaningful | 1|
| Proper spacing and structure | 1|

**Date and Time:**

**Overall Score:** 9 / 9
