# Instructions  

1. Review the Person.java file and ensure you understand how it works
2. Add 3 additional atributes to the Person object that you believe are important pieces of data to store about a person
3. Add encapsulation to the Person class
4. In Main.java we currently have to print out each atribute of a person one by one. Make a new method in the person class called print that prints out the details of a person in a nice format.
5. Use method and constructor overloading to create a second Person constructor and print function depending on the parameters given
6. In Main.java create a loop that asks a user for input via the keyboard to add a new person to an array of people. Once all of the people have been entered, the program prints this data to the console in a neat format.

## Main.java

Here is the oriignal code in Main.java for your reference

```Java
/*
@author
*/

class Main {

  /*
  Main

  @param command line args
  */
  public static void main(String[] args) {
    Person a = new Person("Amy", "Female", 56);
    System.out.println(a.name + " "+ a.gender + " " +a.age);
  }
}
```

## Person.java

Here is the original code in Person.java for your reference

```Java
/*
@author
*/
public class Person {

  public String name;
  public String gender;
  public int age;

  /*
  Person
  A constructor that creates a new Person object

  @Param String name, String gender, int age
  */
  public Person (String name, String gender, int age) {
    this.name = name;
    this.gender = gender;
    this.age = age;
  }
}

```