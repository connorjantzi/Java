/*
@author userCS45
*/
public class Person {
  //Variables that use encapsulation
  final public String name;
  final public String gender;
  final public int age;
  final public String citizenship;
  final public String occupation; 
  final public int birthYear; 

  /*
  Person
  A constructor that creates a new Person object

  @Param String name, String gender, int age, String citizenship, String occupation, int birthYear
  */
  public Person (String name, String gender, int age, String citizenship, String occupation, int birthYear) {
    //References the current object
    this.name = name;
    this.gender = gender;
    this.age = age;
    this.citizenship = citizenship; 
    this.occupation = occupation; 
    this.birthYear = birthYear;
  }
  /*
  Person
  A constructor that creates a new Person object

  @Param String name, String gender
  */
  public Person (String name, String gender) { //Uses constructor overloading
    //References the current object
    this.name = name;
    this.gender = gender;
    //no parameter in contructor
    age = 0;
    citizenship = "Unknown"; 
    occupation = "Unknown"; 
    birthYear = 0;
  }
  /*
  Person
  A method to print the persons information

  @Param String name, String gender, int age, String citizenship, String occupation, int birthYear
  */
  public void print (String name, String gender, int age, String citizenship, String occupation, int birthYear){
    //Print information
    System.out.println("Person Information: ");
    System.out.println("Name: " + name);
    System.out.println("Gender: " + gender);
    System.out.println("Age: " + age);
    System.out.println("Citizenship: " + citizenship);
    System.out.println("Occupation: " + occupation);
    System.out.println("Birth year: " + birthYear);
    System.out.println("*******************");
  }
  /*
  Person
  A method to print the persons information

  @Param String name, String gender
  */
  public void print (String name, String gender){//Uses method overloading
    //Print information
    System.out.println("Person Information: ");
    System.out.println("Name: " + name);
    System.out.println("Gender: " + gender);
    System.out.println("*******************");
  }
}
