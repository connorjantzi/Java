/*
@author userCS45
*/
import java.util.Scanner;

class Main {

  /*
  Main

  @param command line args
  */
  public static void main(String[] args) {
    int numOfPeopleInput = 0; //Number of people the user will input
    Scanner scanner = new Scanner(System.in);//Open scanner
    
    System.out.println("How many people do you want to enter? Eg. '3'");
    numOfPeopleInput = scanner.nextInt(); 
    //Creating variables
    String name;
    String gender;
    int age;
    String citizenship;
    String occupation;
    int birthYear;
    String furtherInformationProvided;

    Person[] a = new Person[numOfPeopleInput];

    //Looping through the number of people the user wil input
    for(int i = 0; i< numOfPeopleInput; i++){
      //Inputting informatin into various arrays
      System.out.println("Please Input Information");
      System.out.println("Name:");
      name = scanner.next();
      System.out.println("Gender:");
      gender = scanner.next();
      //Check if the user wants to enter the remaining information
      System.out.println("Is that all you want to enter? 'y' or 'n'");
      furtherInformationProvided = scanner.next(); 
      if(furtherInformationProvided.equals("n")){ //If they want to put in more information
        System.out.println("age:");
        age = scanner.nextInt();
        System.out.println("Citizenship:");
        citizenship = scanner.next();
        System.out.println("Occupation:");
        occupation = scanner.next();
        System.out.println("Birth year:");
        birthYear = scanner.nextInt();
        //Adding person object with 6 parameters to array 
        a[i] = new Person (name, gender, age, citizenship, occupation, birthYear);
        //Calling the print method
        a[i].print(name, gender, age, citizenship, occupation, birthYear); 
      }else if (furtherInformationProvided.equals("y")){ //If the user only entered the name and gender
        //Adding person object with 2 parameters to array 
        a[i] = new Person (name, gender);
        a[i].print(name, gender); 
      }
    }
    scanner.close();//Close scanner
  }
}
