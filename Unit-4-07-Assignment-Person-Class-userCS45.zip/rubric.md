## Rubric

| Description | 1 mark each | 
| --- | --- |
| 3 new and appropriate attributes added to the Person class |1 |
| Print method added to the Person class |1 |
| Print method prints out each attribute in a neat format |1 |
| Array of people is created using user input |1 |
| Output matches expectations |1 |
| Encapsulation is used |0 |
| Method overloading is used |1 |
| Proper java conventions used |1 |
| Line comments are present |1 |
| Line comments are used effectively | 1|


**Date and Time:**

**Overall Grade:** 9/10