//@author userCS45
import java.util.Arrays;
class Main {
  /**
   * This method takes the string and removes the puncuation then return the desired string
   *
   * @param  input
   * @return  output
   */
  public static String removePuncuation(String inputString){ 
    StringBuffer output = new StringBuffer(inputString); //Using buffer string
    for(int i = 0; i < inputString.length(); i++){ //incrementing through string
      
      if ((inputString.charAt(i) >= 65 && inputString.charAt(i) <= 90) || (inputString.charAt(i) >= 97 && inputString.charAt(i) <= 122)||inputString.charAt(i) >= 48 && inputString.charAt(i) <= 57){ //is it is a letter or nuber
        
      }else{ 
        output.deleteCharAt(i); //delete other characters
      }
    }
    //System.out.println(output); 
    String finalString = output.toString(); //convert back to string
    return finalString; //return final string
  }
   /**
   * This method takes two strign an determines if the two strings are anagrams
   *
   * @param a & b
   * @return boolean
   */
  public static boolean isAnagram(String stringOne, String stringTwo){
    //Put string to lower case
    stringOne = stringOne.toLowerCase(); 
    stringTwo = stringTwo.toLowerCase();
    //Get rid of white space
    stringOne = stringOne.replaceAll("\\s",""); 
    stringTwo = stringTwo.replaceAll("\\s","");
    //Get rid of puncuation by calling function
    stringOne = removePuncuation(stringOne);
    stringTwo = removePuncuation(stringTwo);
    //Check if the word if the same
    if(stringOne.equals(stringTwo)){
      return false;
    }
    //sort string
    char sortStringOne[] = stringOne.toCharArray();
    char sortStringTwo[] = stringTwo.toCharArray();
    Arrays.sort(sortStringOne);
    Arrays.sort(sortStringTwo);
    //check if the strings containt he same letters
    if(Arrays.equals(sortStringOne, sortStringTwo)){
      return true; 
    }else{
      return false;
    }
     
  }
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    //tests
    System.out.println("banana, potato - " + isAnagram("banana", "potato"));
    System.out.println("banana, Banana! - " + isAnagram("banana", "Banana!"));
    System.out.println("123, 321 - " + isAnagram("123", "321"));
    System.out.println("silent, listen - " + isAnagram("silent", "listen"));
    System.out.println("Tom Marvolo Riddle, I am Lord Voldemort! - "  + isAnagram("Tom Marvolo Riddle", "I am Lord Voldemort!"));
  }
}