/**
 *
 * @author userCS45
 */

public class Main {
    
  /**
   * Adds x and y, unless overflow or underflow occurs in which case
   * it throws an Overflow or Underflow exception.
   *
   * @throws IntegerOverflowException, IntegerUnderflowException
   * @param array
   * @return boolean
   */
  public static int safeAdd(int x, int y) throws IntegerOverflowException, IntegerUnderflowException {
    if(x>0 && y>0 && y>=Integer.MAX_VALUE-x){
      System.out.println("Integer overflow");
    }if(x <0 && y< 0 && y<=Integer.MIN_VALUE-x){
      System.out.println("Integer underflow");
    }
    return x + y;
  }
      
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
     try {
       System.out.println(safeAdd(1,2));
       System.out.println(safeAdd(Integer.MAX_VALUE, Integer.MIN_VALUE));
       System.out.println(safeAdd(Integer.MAX_VALUE, 4));
       System.out.println(safeAdd(Integer.MAX_VALUE, Integer.MAX_VALUE));


       System.out.println(safeAdd(1, Integer.MAX_VALUE)); // This should overflow
       System.out.println(safeAdd(-1, Integer.MIN_VALUE)); // This should underflow
     } catch (IntegerOverflowException e) {
       System.out.println(e);
     } catch (IntegerUnderflowException e) {
       System.out.println(e);
     }
  }
}
