/**
 * @author userCS45
 */
 //Include libraries
import java.io.*; 
import java.io.BufferedWriter; 
import java.util.Scanner;
import java.io.FileWriter; 

public class Main {

  /**
   * Replaces all occurrences of *oldName* in *filename* with *newName*.
   *
   * @param filename
   * @param oldName
   * @param newName
   * @throws java.io.IOException when the input file is missing
   */
  public static void replaceName(String filename, String oldName, String newName) throws IOException {
    try {
      FileWriter file = new FileWriter("new" + filename);
      
      BufferedWriter buffer = new BufferedWriter(file);

      File file1 = new File (filename); 
      
      Scanner scanner = new Scanner(file1); 

    
      while(scanner.hasNext()){ 
        String token = scanner.next(); //token is equal to the word inputed form the file
        if (token.equalsIgnoreCase(oldName)|| token.contains(oldName)){ //if the name is found
          token = token.replace(token, newName); //Replace token with new name
        }
        buffer.write(token + " "); //Write back to a new file
      }
    
        
      if (buffer != null) buffer.close(); 
      scanner.close(); 
    } catch (IOException exception) {
      System.out.println("Something is wrong with one of the files.");
    }
  }
    
  /**
   * 
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    try {
      replaceName("hamlet.txt", "Hamlet", "Bob");
      replaceName("macbeth.txt", "Macbeth", "Bob");
      replaceName("othello.txt", "Othello", "Bob");
      replaceName("romeoAndJuliet.txt", "Romeo", "Bob");
    } catch (IOException exception) {
      System.out.println("Something is wrong with the file.");
    }
  }  
}
