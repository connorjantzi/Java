/**
 * @author userCS45
 */

public class Main {

  /**
   * Calculates how much time *seconds* is equivalent to using a combination of
   * days, hours, minutes, and seconds.
   *
   * @param seconds
   * @return int
   */
  public static String timeConversion(int seconds) {
    String timeConverted; // Put the converted dating into this string then will return it to the main function.
    timeConverted = (((seconds / 60) / 60) / 24 + " day(s), "); //Finding and then printing the number of days. 
    seconds = seconds % (60*60*24); //Finding the remainder after the number of day(s) is accounted for. 
    
    timeConverted = timeConverted + ((seconds / 60) / 60 + " hour(s), "); //Finding and printed the number of hours. 
    seconds = seconds % (60*60); //Finding the remainder after the the number of hour(s) is accounted for. 
    
    timeConverted = timeConverted + (seconds/60 + " minute(s), ");// Frinding and printng the number of minutes. 
    
    timeConverted = timeConverted + (seconds%60 + " second(s) "); //printed the remainng seconds left. 

    return timeConverted; //Ending timeConversion fuction and returning to main function 
  }

  /**
   * 
   * @param args the command line arguments
   * @return void
   */
  public static void main(String[] args) {
    System.out.println("60 seconds is equal to: "); //Printing 60 seconds is equal to
    System.out.println(timeConversion(60)); //Printing the time conversion function at 60 seconds. 

    System.out.println("5000 seconds is equal to: ");//Printing 5000 seconds is equal to
    System.out.println(timeConversion(5000)); //Printing the time conversion function at 5000 seconds. 

    System.out.println("100000 seconds is equal to: ");//Printing 100000 seconds is equal to
    System.out.println(timeConversion(100000)); //Printing the time conversion function at 100000 seconds. 
  }
}