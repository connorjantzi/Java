## Rubric

| Description |1 mark each| 
| --- | --- |
| The algorithm for calculating the numbers works. |1 |
| The algorithm is easy to follow. |1 |
| Correct output values |1 |
| Variable names are meaningful and easy to understand. |1 |
| The formatting matches the examples exactly. |1 |
| The three examples work. |1 |
| Java conventions are followed. |1 |
| Line comments are present |1 |
| Line comments are used effectively. They describe program flow and are meaningful |1 |
| Proper spacing and structure | 1|

time covnersion function should return a string and not print a string inside the function

**Date and Time: September 12, 2022**

**Overall Score:**  10 / 10
